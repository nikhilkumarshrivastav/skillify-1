
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import MainLayout from "@/components/layout/MainLayout";
import Reveal from "@/components/ui/reveal";
import { ArrowRight, CheckCircle2 } from "lucide-react";


type Domain =
  | "machine-learning"
  | "web-development"
  | "java"
  | "python"
  | "mobile-development"
  | "deep-learning";

export default function SkillAnalyzer() {
  const [selectedDomain, setSelectedDomain] = useState<Domain | null>(null);
  const [programmingExp, setProgrammingExp] = useState("");
  const [pastExperience, setPastExperience] = useState("");
  const [learningGoal, setLearningGoal] = useState("");
  const [step, setStep] = useState<"domain" | "form">("domain");

  const [webType, setWebType] = useState("");
  const [backendTech, setBackendTech] = useState("");

  const navigate = useNavigate();

  const domains = [
    { id: "machine-learning" as Domain, title: "Machine Learning", icon: "🤖" },
    { id: "web-development" as Domain, title: "Web Development", icon: "🌐" },
    { id: "java" as Domain, title: "Java", icon: "☕" },
    { id: "python" as Domain, title: "Python", icon: "🐍" },
    { id: "mobile-development" as Domain, title: "Mobile Dev", icon: "📱" },
    { id: "deep-learning" as Domain, title: "Deep Learning", icon: "🧠" },
  ];

  const handleStartQuiz = () => {
    if (
      !selectedDomain ||
      !programmingExp ||
      !pastExperience ||
      !learningGoal ||
      (selectedDomain === "web-development" && !webType) ||
      ((webType === "backend" || webType === "fullstack") && !backendTech)
    ) {
      alert("Please fill all fields");
      return;
    }

    localStorage.setItem("selected_domain", selectedDomain);
    localStorage.setItem("programming_exp", programmingExp);
    localStorage.setItem("past_experience", pastExperience);
    localStorage.setItem("learning_goal", learningGoal);

    if (selectedDomain === "web-development") {
      localStorage.setItem("web_type", webType);
      localStorage.setItem("backend_tech", backendTech);
    }

    navigate("/quiz");
  };

  return (
    <MainLayout>
      <div className="flex-1 space-y-8 p-6 lg:p-8">

        <Reveal>
          <h1 className="text-4xl font-bold text-white">Skill Analyzer</h1>
        </Reveal>

        {step === "domain" ? (
          <div className="grid gap-6 md:grid-cols-3 max-w-5xl mx-auto">
            {domains.map((d, i) => (
              <Reveal key={d.id} delay={i * 100}>
                <div
                  onClick={() => {
                    setSelectedDomain(d.id);
                    setStep("form");
                  }}
                  className="group cursor-pointer rounded-2xl border border-white/10 p-6 backdrop-blur-sm transition hover:border-cyan-400 hover:-translate-y-1"
                >
                  <div className="text-5xl mb-4">{d.icon}</div>
                  <h3 className="text-xl font-bold text-white">{d.title}</h3>
                </div>
              </Reveal>
            ))}
          </div>
        ) : (
          <div className="max-w-2xl mx-auto">
            <div className="rounded-2xl border border-white/10 bg-white/5 p-8 backdrop-blur-sm space-y-6">

              {/* Experience */}
              <select
                value={programmingExp}
                onChange={(e) => setProgrammingExp(e.target.value)}
                className="w-full p-3 bg-black/30 text-white rounded"
              >
                <option value="">Programming Experience</option>
                <option value="beginner">Beginner</option>
                <option value="intermediate">Intermediate</option>
                <option value="advanced">Advanced</option>
              </select>

              {/* Past */}
              <select
                value={pastExperience}
                onChange={(e) => setPastExperience(e.target.value)}
                className="w-full p-3 bg-black/30 text-white rounded"
              >
                <option value="">Past Experience</option>
                <option value="none">No prior experience</option>
                <option value="some">Some theoretical knowledge</option>
                <option value="practical">Practical experience</option>
              </select>

              {/* Web Type */}
              {selectedDomain === "web-development" && (
                <select
                  value={webType}
                  onChange={(e) => setWebType(e.target.value)}
                  className="w-full p-3 bg-black/30 text-white rounded"
                >
                  <option value="">Select Focus</option>
                  <option value="frontend">Frontend</option>
                  <option value="backend">Backend</option>
                  <option value="fullstack">Fullstack</option>
                </select>
              )}

              {/* Backend Tech */}
              {(webType === "backend" || webType === "fullstack") && (
                <select
                  value={backendTech}
                  onChange={(e) => setBackendTech(e.target.value)}
                  className="w-full p-3 bg-black/30 text-white rounded"
                >
                  <option value="">Select Backend Tech</option>
                  <option value="java-springboot">Java (Spring Boot)</option>
                  <option value="python-flask">Python(Flask) </option>
                  <option value="python-django">Python(Django)</option>
                  <option value="node-express">Node.js(Express)</option>
                  <option value="php">PHP</option>
                  <option value="csharp">C# (.NET)</option>
                  <option value="go">Go (Golang)</option>
                </select>
              )}

              {/* Goal */}
              <textarea
                value={learningGoal}
                onChange={(e) => setLearningGoal(e.target.value)}
                placeholder="Your goal..."
                className="w-full p-3 bg-black/30 text-white rounded"
              />

              {/* Buttons */}
              <div className="flex gap-4">
                <button
                  onClick={() => {
                    setStep("domain");
                    setSelectedDomain(null);
                  }}
                  className="flex-1 border border-white/10 p-3 text-white rounded"
                >
                  Back
                </button>

                <button
                  onClick={handleStartQuiz}
                  className="flex-1 bg-cyan-500 p-3 text-white rounded"
                >
                  Start Quiz
                </button>
              </div>

            </div>
          </div>
        )}
      </div>
    </MainLayout>
  );
}