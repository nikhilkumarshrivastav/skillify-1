import { useNavigate } from "react-router-dom";
import MainLayout from "@/components/layout/MainLayout";
import Reveal from "@/components/ui/reveal";
import { ArrowRight, BookOpen, MapPin, BarChart3, Sparkles } from "lucide-react";

export default function Dashboard() {
  const navigate = useNavigate();
  const userEmail = localStorage.getItem("user_email") || "user@example.com";
  const userName = localStorage.getItem("user_name") || "Learner";
  const selectedDomain = localStorage.getItem("selected_domain") || null;
  const lastQuizScore = localStorage.getItem("last_quiz_score");
  const skillLevel = localStorage.getItem("skill_level");

  const quotes = [
    "The secret to getting ahead is getting started. - Mark Twain",
    "Learning is a treasure that will follow its owner everywhere. - Chinese Proverb",
    "Success is the sum of small efforts repeated day in and day out. - Robert Collier",
  ];

  const randomQuote = quotes[Math.floor(Math.random() * quotes.length)];

  return (
    <MainLayout>
      <div className="flex-1 space-y-8 p-6 lg:p-8">
        {/* Welcome Section */}
        <Reveal className="space-y-2" delay={0}>
          <h1 className="text-4xl font-bold text-white">
            Welcome back, <span className="bg-gradient-to-r from-cyan-400 to-purple-500 bg-clip-text text-transparent">{userName}</span>!
          </h1>
          <p className="text-muted-foreground">{userEmail}</p>
        </Reveal>

        {/* Status Cards */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          <Reveal
            className="rounded-2xl border border-white/10 bg-gradient-to-br from-white/10 to-white/5 p-6 backdrop-blur-sm transition hover:border-cyan-400/50 hover:bg-white/15"
            delay={100}
          >
            <p className="text-sm font-semibold uppercase tracking-wider text-muted-foreground mb-3">
              Domain Selected
            </p>
            <p className="text-2xl font-bold text-cyan-400">
              {selectedDomain || "None"}
            </p>
            {!selectedDomain && (
              <button
                onClick={() => navigate("/skill-analyzer")}
                className="mt-4 text-xs text-cyan-400 transition hover:text-cyan-300 font-medium"
              >
                Select Domain →
              </button>
            )}
          </Reveal>

          <Reveal
            className="rounded-2xl border border-white/10 bg-gradient-to-br from-white/10 to-white/5 p-6 backdrop-blur-sm transition hover:border-purple-400/50 hover:bg-white/15"
            delay={150}
          >
            <p className="text-sm font-semibold uppercase tracking-wider text-muted-foreground mb-3">
              Learning Progress
            </p>
            <p className="text-2xl font-bold text-purple-400">0%</p>
            <div className="mt-3 h-2 w-full rounded-full bg-white/10">
              <div className="h-full w-0 rounded-full bg-gradient-to-r from-purple-400 to-cyan-400 transition-all duration-500" />
            </div>
          </Reveal>

          <Reveal
            className="rounded-2xl border border-white/10 bg-gradient-to-br from-white/10 to-white/5 p-6 backdrop-blur-sm transition hover:border-cyan-400/50 hover:bg-white/15"
            delay={200}
          >
            <p className="text-sm font-semibold uppercase tracking-wider text-muted-foreground mb-3">
              Last Quiz Score
            </p>
            <p className="text-2xl font-bold text-cyan-400">
              {lastQuizScore ? `${lastQuizScore}%` : "—"}
            </p>
            {!lastQuizScore && (
              <button
                onClick={() => navigate("/skill-analyzer")}
                className="mt-4 text-xs text-cyan-400 transition hover:text-cyan-300 font-medium"
              >
                Take Quiz →
              </button>
            )}
          </Reveal>

          <Reveal
            className="rounded-2xl border border-white/10 bg-gradient-to-br from-white/10 to-white/5 p-6 backdrop-blur-sm transition hover:border-purple-400/50 hover:bg-white/15"
            delay={250}
          >
            <p className="text-sm font-semibold uppercase tracking-wider text-muted-foreground mb-3">
              Skill Level
            </p>
            <p className="text-2xl font-bold text-purple-400">
              {skillLevel || "—"}
            </p>
          </Reveal>
        </div>

        {/* Quick Access Section */}
        <div>
          <Reveal className="mb-6" delay={300}>
            <h2 className="text-2xl font-bold text-white">Quick Access</h2>
          </Reveal>

          <div className="grid gap-6 md:grid-cols-2">
            <Reveal
              className="group relative overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-br from-white/10 to-white/5 p-8 backdrop-blur-sm transition duration-300 hover:border-cyan-400/50 hover:bg-white/15 hover:-translate-y-1"
              delay={350}
            >
              <div className="absolute inset-0 opacity-0 transition duration-300 group-hover:opacity-100 -z-10 bg-gradient-to-br from-cyan-500/10 to-purple-500/10 blur-xl" />
              <div className="flex items-center justify-between">
                <div className="space-y-2">
                  <h3 className="text-xl font-semibold text-white">Skill Analyzer</h3>
                  <p className="text-sm text-muted-foreground">
                    Start your learning journey
                  </p>
                </div>
                <Sparkles className="h-8 w-8 text-cyan-400 flex-shrink-0" />
              </div>
              <button
                onClick={() => navigate("/skill-analyzer")}
                className="mt-6 flex items-center gap-2 text-sm font-semibold text-cyan-400 transition hover:text-cyan-300"
              >
                Get Started <ArrowRight className="h-4 w-4" />
              </button>
            </Reveal>

            <Reveal
              className="group relative overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-br from-white/10 to-white/5 p-8 backdrop-blur-sm transition duration-300 hover:border-purple-400/50 hover:bg-white/15 hover:-translate-y-1"
              delay={400}
            >
              <div className="absolute inset-0 opacity-0 transition duration-300 group-hover:opacity-100 -z-10 bg-gradient-to-br from-purple-500/10 to-cyan-500/10 blur-xl" />
              <div className="flex items-center justify-between">
                <div className="space-y-2">
                  <h3 className="text-xl font-semibold text-white">Recommendations</h3>
                  <p className="text-sm text-muted-foreground">
                    Browse recommended courses
                  </p>
                </div>
                <BookOpen className="h-8 w-8 text-purple-400 flex-shrink-0" />
              </div>
              <button
                onClick={() => navigate("/recommendations")}
                className="mt-6 flex items-center gap-2 text-sm font-semibold text-purple-400 transition hover:text-purple-300"
              >
                Explore <ArrowRight className="h-4 w-4" />
              </button>
            </Reveal>

            <Reveal
              className="group relative overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-br from-white/10 to-white/5 p-8 backdrop-blur-sm transition duration-300 hover:border-cyan-400/50 hover:bg-white/15 hover:-translate-y-1"
              delay={450}
            >
              <div className="absolute inset-0 opacity-0 transition duration-300 group-hover:opacity-100 -z-10 bg-gradient-to-br from-cyan-500/10 to-purple-500/10 blur-xl" />
              <div className="flex items-center justify-between">
                <div className="space-y-2">
                  <h3 className="text-xl font-semibold text-white">Your Roadmap</h3>
                  <p className="text-sm text-muted-foreground">
                    View your learning roadmap
                  </p>
                </div>
                <MapPin className="h-8 w-8 text-cyan-400 flex-shrink-0" />
              </div>
              <button
                onClick={() => navigate("/roadmap")}
                className="mt-6 flex items-center gap-2 text-sm font-semibold text-cyan-400 transition hover:text-cyan-300"
              >
                View <ArrowRight className="h-4 w-4" />
              </button>
            </Reveal>

            <Reveal
              className="group relative overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-br from-white/10 to-white/5 p-8 backdrop-blur-sm transition duration-300 hover:border-purple-400/50 hover:bg-white/15 hover:-translate-y-1"
              delay={500}
            >
              <div className="absolute inset-0 opacity-0 transition duration-300 group-hover:opacity-100 -z-10 bg-gradient-to-br from-purple-500/10 to-cyan-500/10 blur-xl" />
              <div className="flex items-center justify-between">
                <div className="space-y-2">
                  <h3 className="text-xl font-semibold text-white">Progress Tracker</h3>
                  <p className="text-sm text-muted-foreground">
                    View your overall progress
                  </p>
                </div>
                <BarChart3 className="h-8 w-8 text-purple-400 flex-shrink-0" />
              </div>
              <button
                onClick={() => navigate("/profile")}
                className="mt-6 flex items-center gap-2 text-sm font-semibold text-purple-400 transition hover:text-purple-300"
              >
                Check <ArrowRight className="h-4 w-4" />
              </button>
            </Reveal>
          </div>
        </div>

        {/* Motivational Quote */}
        <Reveal
          className="mt-12 rounded-2xl border border-cyan-400/30 bg-gradient-to-r from-cyan-500/10 to-purple-500/10 p-8 backdrop-blur-sm"
          delay={550}
        >
          <p className="text-center text-lg text-white italic">
            "{randomQuote}"
          </p>
        </Reveal>
      </div>
    </MainLayout>
  );
}
