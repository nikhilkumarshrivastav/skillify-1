import { useState, useEffect } from "react";
import MainLayout from "@/components/layout/MainLayout";
import Reveal from "@/components/ui/reveal";
import { User, Mail, Target, BarChart3, BookOpen, Save, X, Loader2 } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { supabase } from "@/lib/supabase";
import { useToast } from "@/hooks/use-toast";

export default function Profile() {
  const { user } = useAuth();
  const { toast } = useToast();

  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState("");
  const [isSaving, setIsSaving] = useState(false);

  // Additional state for Settings Form
  const [isEditingAccountEmail, setIsEditingAccountEmail] = useState(false);
  const [editAccountEmail, setEditAccountEmail] = useState("");
  const [isEditingAccountName, setIsEditingAccountName] = useState(false);
  const [editAccountName, setEditAccountName] = useState("");

  // Read authentic data from Supabase Auth
  const userName = user?.user_metadata?.name || "User";
  const userEmail = user?.email || "user@example.com";

  useEffect(() => {
    setEditName(user?.user_metadata?.name || "");
    setEditAccountName(user?.user_metadata?.name || "");
    setEditAccountEmail(user?.email || "");
  }, [user, isEditing, isEditingAccountName, isEditingAccountEmail]);

  const handleSaveProfile = async () => {
    if (!user) return;
    setIsSaving(true);
    try {
      // 1. Update Auth Metadata
      const { error: authError } = await supabase.auth.updateUser({
        data: { name: editName }
      });
      if (authError) throw authError;

      // 2. Update Public Profile Table
      const { error: dbError } = await supabase.from('profiles')
        .update({ full_name: editName })
        .eq('id', user.id);

      if (dbError) throw dbError;

      toast({
        title: "Profile updated!",
        description: "Your details have been saved successfully.",
      });
      setIsEditing(false);
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error saving profile",
        description: error.message || "Something went wrong.",
      });
    } finally {
      setIsSaving(false);
    }
  };

  const handleSaveAccountEmail = async () => {
    if (!user) return;
    setIsSaving(true);
    try {
      const { error } = await supabase.auth.updateUser({ email: editAccountEmail });
      if (error) throw error;
      const { error: dbError } = await supabase.from('profiles').update({ email: editAccountEmail }).eq('id', user.id);
      if (dbError && dbError.code !== 'PGRST204') console.error(dbError); // Ignore warning if email column doesn't exist

      toast({ title: "Email updated!", description: "Your email has been saved." });
      setIsEditingAccountEmail(false);
    } catch (error: any) {
      toast({ variant: "destructive", title: "Error saving email", description: error.message || "Something went wrong." });
    } finally {
      setIsSaving(false);
    }
  };

  const handleSaveAccountName = async () => {
    if (!user) return;
    setIsSaving(true);
    try {
      const { error: authError } = await supabase.auth.updateUser({ data: { name: editAccountName } });
      if (authError) throw authError;
      const { error: dbError } = await supabase.from('profiles').update({ full_name: editAccountName }).eq('id', user.id);
      if (dbError) throw dbError;

      toast({ title: "Name updated!", description: "Your name has been saved." });
      setIsEditingAccountName(false);
    } catch (error: any) {
      toast({ variant: "destructive", title: "Error saving name", description: error.message || "Something went wrong." });
    } finally {
      setIsSaving(false);
    }
  };

  const selectedDomain = localStorage.getItem("selected_domain") || "Not selected";
  const skillLevel = localStorage.getItem("skill_level") || "Not assessed";
  const lastQuizScore = localStorage.getItem("last_quiz_score");
  const completedRoadmapStr = localStorage.getItem("roadmap_completed") || "[]";
  const completedSteps = JSON.parse(completedRoadmapStr).length;

  const domainTitle = selectedDomain === "machine-learning" ? "Machine Learning" : selectedDomain === "web-development" ? "Web Development" : selectedDomain;

  return (
    <MainLayout>
      <div className="flex-1 space-y-8 p-6 lg:p-8">
        {/* Profile Header */}
        <Reveal className="space-y-6" delay={0}>
          <div className="rounded-2xl border border-white/10 bg-gradient-to-br from-white/10 to-white/5 p-8 backdrop-blur-sm">
            <div className="flex flex-col items-center gap-6 sm:flex-row sm:items-start">
              {/* Avatar */}
              <div className="flex h-24 w-24 items-center justify-center rounded-full bg-gradient-to-br from-cyan-500/30 to-purple-500/30 text-4xl font-bold text-cyan-400 flex-shrink-0">
                {userName.charAt(0).toUpperCase()}
              </div>

              {/* Profile Info */}
              <div className="flex-1 text-center sm:text-left">
                {isEditing ? (
                  <div className="mb-2 max-w-sm mx-auto sm:mx-0">
                    <p className="text-sm font-semibold mb-1 text-white">Full Name</p>
                    <input
                      type="text"
                      value={editName}
                      onChange={(e) => setEditName(e.target.value)}
                      className="w-full bg-white/10 border border-white/20 rounded-md px-3 py-2 text-white focus:outline-none focus:border-cyan-400"
                    />
                  </div>
                ) : (
                  <h1 className="text-3xl font-bold text-white">{userName}</h1>
                )}
                <p className="text-muted-foreground">{userEmail}</p>

                <div className="mt-4 flex flex-col gap-2 sm:flex-row sm:gap-6">
                  <div>
                    <p className="text-xs text-muted-foreground uppercase">Domain</p>
                    <p className="font-semibold text-foreground">{domainTitle}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground uppercase">Skill Level</p>
                    <p className="font-semibold text-purple-400">{skillLevel}</p>
                  </div>
                </div>
              </div>

              {isEditing ? (
                <div className="flex flex-col sm:flex-row gap-3">
                  <button
                    onClick={() => setIsEditing(false)}
                    disabled={isSaving}
                    className="flex items-center justify-center gap-2 rounded-lg bg-gray-500/20 px-6 py-2 font-medium text-gray-300 transition hover:bg-gray-500/40 border border-gray-500/30"
                  >
                    <X className="h-4 w-4" /> Cancel
                  </button>
                  <button
                    onClick={handleSaveProfile}
                    disabled={isSaving}
                    className="flex items-center justify-center gap-2 rounded-lg bg-cyan-500/30 px-6 py-2 font-medium text-cyan-400 transition hover:bg-cyan-500/50 border border-cyan-400/30"
                  >
                    {isSaving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                    Save
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => setIsEditing(true)}
                  className="rounded-lg bg-cyan-500/30 px-6 py-2 font-medium text-cyan-400 transition hover:bg-cyan-500/50 border border-cyan-400/30"
                >
                  Edit Profile
                </button>
              )}
            </div>
          </div>
        </Reveal>

        {/* Stats Grid */}
        <Reveal className="grid gap-6 md:grid-cols-2 lg:grid-cols-4" delay={100}>
          <div className="rounded-xl border border-white/10 bg-gradient-to-br from-white/10 to-white/5 p-6 backdrop-blur-sm">
            <div className="flex items-center gap-3 mb-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-cyan-500/20 text-cyan-400">
                <BarChart3 className="h-5 w-5" />
              </div>
              <p className="text-xs font-semibold uppercase text-muted-foreground">Quiz Score</p>
            </div>
            <p className="text-2xl font-bold text-cyan-400">
              {lastQuizScore ? `${lastQuizScore}%` : "—"}
            </p>
          </div>

          <div className="rounded-xl border border-white/10 bg-gradient-to-br from-white/10 to-white/5 p-6 backdrop-blur-sm">
            <div className="flex items-center gap-3 mb-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-purple-500/20 text-purple-400">
                <BookOpen className="h-5 w-5" />
              </div>
              <p className="text-xs font-semibold uppercase text-muted-foreground">Courses</p>
            </div>
            <p className="text-2xl font-bold text-purple-400">0</p>
          </div>

          <div className="rounded-xl border border-white/10 bg-gradient-to-br from-white/10 to-white/5 p-6 backdrop-blur-sm">
            <div className="flex items-center gap-3 mb-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-green-500/20 text-green-400">
                <Target className="h-5 w-5" />
              </div>
              <p className="text-xs font-semibold uppercase text-muted-foreground">Completed</p>
            </div>
            <p className="text-2xl font-bold text-green-400">{completedSteps}</p>
          </div>

          <div className="rounded-xl border border-white/10 bg-gradient-to-br from-white/10 to-white/5 p-6 backdrop-blur-sm">
            <div className="flex items-center gap-3 mb-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-yellow-500/20 text-yellow-400">
                🔥
              </div>
              <p className="text-xs font-semibold uppercase text-muted-foreground">Streak</p>
            </div>
            <p className="text-2xl font-bold text-yellow-400">0 days</p>
          </div>
        </Reveal>

        {/* Learning Journey */}
        <Reveal className="rounded-2xl border border-white/10 bg-gradient-to-br from-white/10 to-white/5 p-8 backdrop-blur-sm" delay={200}>
          <h2 className="mb-6 text-2xl font-bold text-white">Your Learning Journey</h2>

          <div className="space-y-4">
            <div className="flex items-start gap-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-green-500/20 text-green-400 flex-shrink-0 mt-1">
                ✓
              </div>
              <div>
                <h3 className="font-semibold text-green-400">Profile Created</h3>
                <p className="text-sm text-muted-foreground">You've successfully set up your Skillify account</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-green-500/20 text-green-400 flex-shrink-0 mt-1">
                ✓
              </div>
              <div>
                <h3 className="font-semibold text-green-400">Domain Selected</h3>
                <p className="text-sm text-muted-foreground">You chose {domainTitle} as your learning domain</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              {lastQuizScore ? (
                <>
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-green-500/20 text-green-400 flex-shrink-0 mt-1">
                    ✓
                  </div>
                  <div>
                    <h3 className="font-semibold text-green-400">Quiz Completed</h3>
                    <p className="text-sm text-muted-foreground">You scored {lastQuizScore}% and achieved {skillLevel} skill level</p>
                  </div>
                </>
              ) : (
                <>
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gray-500/20 text-gray-400 flex-shrink-0 mt-1">
                    ○
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-400">Quiz Pending</h3>
                    <p className="text-sm text-muted-foreground">Take the skill assessment quiz to get started</p>
                  </div>
                </>
              )}
            </div>
          </div>
        </Reveal>

        {/* Account Settings */}
        <Reveal className="rounded-2xl border border-white/10 bg-gradient-to-br from-white/10 to-white/5 p-8 backdrop-blur-sm" delay={250}>
          <h2 className="mb-6 text-2xl font-bold text-white">Account Settings</h2>

          <div className="space-y-4">
            <div className="flex items-center justify-between rounded-lg border border-white/10 bg-white/5 p-4">
              <div className="flex items-center gap-3 w-3/4">
                <Mail className="h-5 w-5 text-muted-foreground flex-shrink-0" />
                <div className="w-full">
                  <p className="text-sm font-semibold text-foreground">Email Address</p>
                  {isEditingAccountEmail ? (
                    <input
                      type="email"
                      value={editAccountEmail}
                      onChange={e => setEditAccountEmail(e.target.value)}
                      className="w-full max-w-xs mt-1 bg-white/10 border border-white/20 rounded-md px-2 py-1 text-white text-sm focus:outline-none focus:border-cyan-400"
                    />
                  ) : (
                    <p className="text-sm text-muted-foreground">{userEmail}</p>
                  )}
                </div>
              </div>
              {isEditingAccountEmail ? (
                <div className="flex gap-3">
                  <button onClick={() => setIsEditingAccountEmail(false)} disabled={isSaving} className="text-sm text-gray-400 hover:text-gray-300"><X className="h-4 w-4" /></button>
                  <button onClick={handleSaveAccountEmail} disabled={isSaving} className="text-sm text-cyan-400 hover:text-cyan-300">{isSaving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}</button>
                </div>
              ) : (
                <button onClick={() => setIsEditingAccountEmail(true)} className="text-sm text-cyan-400 transition hover:text-cyan-300">Change</button>
              )}
            </div>

            <div className="flex items-center justify-between rounded-lg border border-white/10 bg-white/5 p-4">
              <div className="flex items-center gap-3 w-3/4">
                <User className="h-5 w-5 text-muted-foreground flex-shrink-0" />
                <div className="w-full">
                  <p className="text-sm font-semibold text-foreground">Full Name</p>
                  {isEditingAccountName ? (
                    <input
                      type="text"
                      value={editAccountName}
                      onChange={e => setEditAccountName(e.target.value)}
                      className="w-full max-w-xs mt-1 bg-white/10 border border-white/20 rounded-md px-2 py-1 text-white text-sm focus:outline-none focus:border-cyan-400"
                    />
                  ) : (
                    <p className="text-sm text-muted-foreground">{userName}</p>
                  )}
                </div>
              </div>
              {isEditingAccountName ? (
                <div className="flex gap-3">
                  <button onClick={() => setIsEditingAccountName(false)} disabled={isSaving} className="text-sm text-gray-400 hover:text-gray-300"><X className="h-4 w-4" /></button>
                  <button onClick={handleSaveAccountName} disabled={isSaving} className="text-sm text-cyan-400 hover:text-cyan-300">{isSaving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}</button>
                </div>
              ) : (
                <button
                  onClick={() => setIsEditingAccountName(true)}
                  className="text-sm text-cyan-400 transition hover:text-cyan-300"
                >
                  Edit
                </button>
              )}
            </div>
          </div>
        </Reveal>
      </div>
    </MainLayout>
  );
}
