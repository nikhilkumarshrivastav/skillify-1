import { useState } from "react";
import MainLayout from "@/components/layout/MainLayout";
import { Play } from "lucide-react";

type Video = {
  title: string;
  youtubeId: string;
};

type Course = {
  id: number;
  title: string;
  description: string;
  platform: string;
  difficulty: "Beginner" | "Intermediate" | "Advanced";
  category: string;
  thumbnail: string;
  color: string;
  videos: Video[];
  chapters: string[]; // ✅ added
};

const courses: Record<string, Course[]> = {
  "machine-learning": [
    {
      id: 1,
      title: "Machine Learning Fundamentals",
      description: "Learn the basics of ML algorithms",
      platform: "Coursera",
      difficulty: "Beginner",
      category: "Fundamentals",
      thumbnail: "📚",
      color: "from-blue-500/20 to-cyan-500/10",
      videos: [],
      chapters: [
        "linear regression",
        "logistic regression",
        "decision tree",
        "clustering",
      ],
    },
    {
      id: 2,
      title: "Deep Learning",
      description: "Neural networks and deep learning",
      platform: "YouTube",
      difficulty: "Intermediate",
      category: "Advanced Topics",
      thumbnail: "🧠",
      color: "from-purple-500/20 to-pink-500/10",
      videos: [],
      chapters: [
        "neural networks",
        "cnn",
        "rnn",
        "transformers",
      ],
    },
  ],
  "web-development": [
    {
      id: 1,
      title: "React Development",
      description: "Build modern web apps",
      platform: "YouTube",
      difficulty: "Intermediate",
      category: "Frontend",
      thumbnail: "⚛️",
      color: "from-cyan-500/20 to-blue-500/10",
      videos: [],
      chapters: [
        "react basics",
        "react hooks",
        "state management",
        "react router",
      ],
    },
  ],
};

export default function Recommendations() {
  const [filter, setFilter] = useState<string>("all");
  const [activeCourse, setActiveCourse] = useState<Course | null>(null);
  const [activeVideoId, setActiveVideoId] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [expandedCourseId, setExpandedCourseId] = useState<number | null>(null); // ✅ new

  const domain =
    (localStorage.getItem("selected_domain") ||
      "machine-learning") as keyof typeof courses;

  const domainCourses = courses[domain] || [];

  const categories = ["all", ...new Set(domainCourses.map((c) => c.category))];
  const filteredCourses =
    filter === "all"
      ? domainCourses
      : domainCourses.filter((c) => c.category === filter);

  // API call
  const fetchRecommendations = async (topic: string): Promise<Video[]> => {
    setLoading(true);
    try {
      const res = await fetch(
        `http://127.0.0.1:8000/recommend?topic=${encodeURIComponent(topic)}`
      );
      const data = await res.json();

      return data.results.map((v: any) => ({
        title: v.title,
        youtubeId: v.link.split("v=")[1],
      }));
    } catch (err) {
      console.error("API Error:", err);
      return [];
    } finally {
      setLoading(false);
    }
  };

  return (
    <MainLayout>
      <div className="p-6">
        <h1 className="text-3xl text-white mb-4">Recommendations</h1>

        {/* Filter */}
        <div className="flex gap-2 mb-6">
          {categories.map((cat) => (
            <button key={cat} onClick={() => setFilter(cat)}>
              {cat}
            </button>
          ))}
        </div>

        {/* Courses */}
        <div className="grid grid-cols-2 gap-4">
          {filteredCourses.map((course) => (
            <div key={course.id} className="p-4 border rounded-xl">

              {/* Click to Expand */}
              <h3
                className="text-white cursor-pointer font-semibold"
                onClick={() =>
                  setExpandedCourseId(
                    expandedCourseId === course.id ? null : course.id
                  )
                }
              >
                {course.title}
              </h3>

              {/* Chapters */}
              {expandedCourseId === course.id && (
                <div className="mt-3 space-y-2">
                  {course.chapters.map((chapter, i) => (
                    <button
                      key={i}
                      onClick={async () => {
                        const videos = await fetchRecommendations(
                          `${course.title} ${chapter}`
                        );

                        const updatedCourse = {
                          ...course,
                          videos: videos,
                        };

                        setActiveCourse(updatedCourse);

                        if (videos.length > 0) {
                          setActiveVideoId(videos[0].youtubeId);
                        }
                      }}
                      className="block text-sm text-cyan-400 hover:underline"
                    >
                      ▶ {chapter}
                    </button>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Loading */}
        {loading && <p className="text-white mt-4">Loading...</p>}

        {/* Video Modal */}
        {activeCourse && activeVideoId && (
          <div className="fixed inset-0 bg-black/90 flex">
            <div className="flex-1">
              <iframe
                width="100%"
                height="100%"
                src={`https://www.youtube.com/embed/${activeVideoId}`}
                allowFullScreen
              ></iframe>
            </div>

            <div className="w-80 bg-black p-4 overflow-y-auto">
              {activeCourse.videos.map((vid, i) => (
                <div
                  key={i}
                  onClick={() => setActiveVideoId(vid.youtubeId)}
                  className="cursor-pointer mb-3 text-white"
                >
                  {vid.title}
                </div>
              ))}
            </div>

            <button
              onClick={() => {
                setActiveCourse(null);
                setActiveVideoId(null);
              }}
              className="absolute top-4 right-4 text-white"
            >
              ✕
            </button>
          </div>
        )}
      </div>
    </MainLayout>
  );
}