import { useNavigate } from "react-router-dom";
import MainLayout from "@/components/layout/MainLayout";
import Reveal from "@/components/ui/reveal";
import { ArrowRight, CheckCircle2, AlertCircle } from "lucide-react";

export default function Results() {
  const navigate = useNavigate();

  const score = parseInt(localStorage.getItem("last_quiz_score") || "0");
  const skillLevel = localStorage.getItem("skill_level") || "Beginner";
  const domain = localStorage.getItem("selected_domain") || "machine-learning";
  const domainTitle = domain === "machine-learning" ? "Machine Learning" : "Web Development";

  // Mock section scores
  const sections = [
    { name: "Fundamentals", score: Math.floor(Math.random() * 40) + 40 },
    { name: "Core Concepts", score: Math.floor(Math.random() * 40) + 40 },
    { name: "Advanced Topics", score: Math.floor(Math.random() * 40) + 30 },
  ];

  const strengths = sections.filter((s) => s.score >= 70);
  const weaknesses = sections.filter((s) => s.score < 50);

  const getScoreColor = (s: number) => {
    if (s >= 80) return "text-green-400";
    if (s >= 60) return "text-yellow-400";
    return "text-red-400";
  };

  const insights = {
    "machine-learning": [
      "Your understanding of AI fundamentals is solid. Focus on advanced ML algorithms and deep learning concepts.",
      "Consider exploring practical projects to apply theoretical knowledge.",
      "Mathematics foundation is important for advanced ML topics.",
    ],
    "web-development": [
      "You have a good grasp of HTML and CSS. JavaScript and frameworks are your next focus areas.",
      "Build real projects to strengthen your practical skills.",
      "Modern web development requires continuous learning of new tools and frameworks.",
    ],
  };

  const selectedInsights = insights[domain as keyof typeof insights] || [];

  return (
    <MainLayout>
      <div className="flex-1 space-y-8 p-6 lg:p-8">
        {/* Score Card */}
        <Reveal className="space-y-6" delay={0}>
          <div className="rounded-2xl border border-cyan-400/30 bg-gradient-to-br from-cyan-500/20 to-purple-500/10 p-8 backdrop-blur-sm text-center">
            <h1 className="text-4xl font-bold text-white mb-2">Quiz Completed! 🎉</h1>
            <p className="text-muted-foreground mb-8">Here's your detailed assessment</p>

            <div className="mb-8 grid grid-cols-3 gap-6">
              {/* Score */}
              <div className="rounded-xl border border-white/10 bg-white/5 p-6">
                <p className="text-sm text-muted-foreground mb-2">Your Score</p>
                <p className={`text-4xl font-bold ${score >= 70 ? "text-green-400" : score >= 50 ? "text-yellow-400" : "text-red-400"}`}>
                  {score}%
                </p>
              </div>

              {/* Skill Level */}
              <div className="rounded-xl border border-white/10 bg-white/5 p-6">
                <p className="text-sm text-muted-foreground mb-2">Skill Level</p>
                <p className="text-3xl font-bold text-purple-400">{skillLevel}</p>
              </div>

              {/* Domain */}
              <div className="rounded-xl border border-white/10 bg-white/5 p-6">
                <p className="text-sm text-muted-foreground mb-2">Domain</p>
                <p className="text-xl font-bold text-cyan-400">{domainTitle}</p>
              </div>
            </div>
          </div>
        </Reveal>

        {/* Section Scores */}
        <Reveal className="space-y-4" delay={100}>
          <h2 className="text-2xl font-bold text-white">Performance by Section</h2>
          <div className="grid gap-4 md:grid-cols-3">
            {sections.map((section, index) => (
              <div
                key={section.name}
                className="rounded-xl border border-white/10 bg-gradient-to-br from-white/10 to-white/5 p-6 backdrop-blur-sm"
              >
                <p className="text-sm text-muted-foreground mb-3">{section.name}</p>
                <p className={`text-3xl font-bold mb-3 ${getScoreColor(section.score)}`}>
                  {section.score}%
                </p>
                <div className="h-2 w-full rounded-full bg-white/10">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      section.score >= 70
                        ? "bg-green-400"
                        : section.score >= 60
                          ? "bg-yellow-400"
                          : "bg-red-400"
                    }`}
                    style={{ width: `${section.score}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </Reveal>

        {/* Strengths and Weaknesses */}
        <div className="grid gap-6 lg:grid-cols-2">
          <Reveal delay={150}>
            <div className="rounded-2xl border border-white/10 bg-gradient-to-br from-white/10 to-white/5 p-6 backdrop-blur-sm">
              <div className="flex items-center gap-3 mb-4">
                <CheckCircle2 className="h-6 w-6 text-green-400" />
                <h3 className="text-xl font-bold text-white">Strengths</h3>
              </div>
              {strengths.length > 0 ? (
                <ul className="space-y-2">
                  {strengths.map((s) => (
                    <li key={s.name} className="flex items-center gap-2 text-foreground">
                      <span className="h-2 w-2 rounded-full bg-green-400" />
                      {s.name} ({s.score}%)
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-muted-foreground">No strong sections yet. Keep practicing!</p>
              )}
            </div>
          </Reveal>

          <Reveal delay={200}>
            <div className="rounded-2xl border border-white/10 bg-gradient-to-br from-white/10 to-white/5 p-6 backdrop-blur-sm">
              <div className="flex items-center gap-3 mb-4">
                <AlertCircle className="h-6 w-6 text-red-400" />
                <h3 className="text-xl font-bold text-white">Areas to Improve</h3>
              </div>
              {weaknesses.length > 0 ? (
                <ul className="space-y-2">
                  {weaknesses.map((s) => (
                    <li key={s.name} className="flex items-center gap-2 text-foreground">
                      <span className="h-2 w-2 rounded-full bg-red-400" />
                      {s.name} ({s.score}%)
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-muted-foreground">Great job! Focus on mastering advanced topics.</p>
              )}
            </div>
          </Reveal>
        </div>

        {/* AI Insights */}
        <Reveal className="rounded-2xl border border-purple-400/30 bg-gradient-to-br from-purple-500/20 to-cyan-500/10 p-8 backdrop-blur-sm" delay={250}>
          <h3 className="mb-4 text-xl font-bold text-white">AI-Generated Insights</h3>
          <ul className="space-y-3">
            {selectedInsights.map((insight, index) => (
              <li key={index} className="flex items-start gap-3">
                <span className="mt-1 inline-flex h-2 w-2 rounded-full bg-purple-400 flex-shrink-0" />
                <p className="text-foreground">{insight}</p>
              </li>
            ))}
          </ul>
        </Reveal>

        {/* Action Buttons */}
        <Reveal className="flex flex-col gap-4 sm:flex-row pt-4" delay={300}>
          <button
            onClick={() => navigate("/recommendations")}
            className="btn-glow flex flex-1 items-center justify-center gap-2 px-6 py-3 text-base font-semibold uppercase tracking-[0.3em] shadow-glow"
          >
            View Recommended Courses <ArrowRight className="h-4 w-4" />
          </button>
          <button
            onClick={() => navigate("/roadmap")}
            className="flex flex-1 items-center justify-center gap-2 rounded-lg border border-white/10 bg-white/5 px-6 py-3 font-semibold text-foreground transition hover:border-white/30 hover:bg-white/10"
          >
            Generate My Roadmap <ArrowRight className="h-4 w-4" />
          </button>
          <button
            onClick={() => navigate("/dashboard")}
            className="flex flex-1 items-center justify-center gap-2 rounded-lg border border-white/10 bg-white/5 px-6 py-3 font-semibold text-foreground transition hover:border-white/30 hover:bg-white/10"
          >
            Back to Dashboard
          </button>
        </Reveal>
      </div>
    </MainLayout>
  );
}
