import { useState } from "react";
import MainLayout from "@/components/layout/MainLayout";
import Reveal from "@/components/ui/reveal";
import { CheckCircle2, Circle } from "lucide-react";

type Step = {
  id: number;
  title: string;
  description: string;
  section: string;
};

const roadmaps: Record<string, Step[]> = {
  "machine-learning": [
    // Prerequisites
    { id: 1, title: "Linear Algebra Basics", description: "Matrices, vectors, and operations", section: "Prerequisites" },
    { id: 2, title: "Calculus Fundamentals", description: "Derivatives, gradients, and optimization", section: "Prerequisites" },
    { id: 3, title: "Python Programming", description: "Core Python concepts and libraries", section: "Prerequisites" },

    // Core Learning
    { id: 4, title: "Supervised Learning", description: "Regression and classification algorithms", section: "Core Learning" },
    { id: 5, title: "Unsupervised Learning", description: "Clustering and dimensionality reduction", section: "Core Learning" },
    { id: 6, title: "Model Evaluation", description: "Metrics, validation, and cross-validation", section: "Core Learning" },

    // Advanced
    { id: 7, title: "Neural Networks", description: "Deep learning and backpropagation", section: "Advanced Topics" },
    { id: 8, title: "Convolutional Networks", description: "Image processing and computer vision", section: "Advanced Topics" },

    // Projects
    { id: 9, title: "Housing Price Prediction", description: "Regression project with real data", section: "Projects" },
    { id: 10, title: "Iris Classification", description: "Multi-class classification challenge", section: "Projects" },

    // Certifications
    { id: 11, title: "TensorFlow Certification", description: "Official ML engineer certification", section: "Certifications" },
  ],
  "web-development": [
    // Prerequisites
    { id: 1, title: "HTML Fundamentals", description: "Structure and semantic HTML", section: "Prerequisites" },
    { id: 2, title: "CSS Essentials", description: "Styling, layouts, and responsive design", section: "Prerequisites" },
    { id: 3, title: "JavaScript Basics", description: "Variables, functions, and DOM manipulation", section: "Prerequisites" },

    // Core Learning
    { id: 4, title: "Advanced CSS", description: "Flexbox, Grid, and animations", section: "Core Learning" },
    { id: 5, title: "ES6+ JavaScript", description: "Modern JavaScript features and concepts", section: "Core Learning" },
    { id: 6, title: "React Fundamentals", description: "Components, hooks, and state management", section: "Core Learning" },

    // Advanced
    { id: 7, title: "Backend with Node.js", description: "Server-side development and APIs", section: "Advanced Topics" },
    { id: 8, title: "Databases", description: "SQL, NoSQL, and data management", section: "Advanced Topics" },

    // Projects
    { id: 9, title: "Personal Portfolio", description: "Showcase your projects online", section: "Projects" },
    { id: 10, title: "E-Commerce Site", description: "Full-stack web application", section: "Projects" },

    // Certifications
    { id: 11, title: "AWS Web Developer Certification", description: "AWS certified developer", section: "Certifications" },
  ],
};

export default function Roadmap() {
  const [completed, setCompleted] = useState<number[]>(() => {
    const saved = localStorage.getItem("roadmap_completed");
    return saved ? JSON.parse(saved) : [];
  });

  const domain = (localStorage.getItem("selected_domain") || "machine-learning") as keyof typeof roadmaps;
  const domainTitle = domain === "machine-learning" ? "Machine Learning" : "Web Development";
  const roadmapSteps = roadmaps[domain] || [];

  const toggleStep = (id: number) => {
    const newCompleted = completed.includes(id)
      ? completed.filter((c) => c !== id)
      : [...completed, id];
    setCompleted(newCompleted);
    localStorage.setItem("roadmap_completed", JSON.stringify(newCompleted));
  };

  const sections = [...new Set(roadmapSteps.map((s) => s.section))];
  const progress = (completed.length / roadmapSteps.length) * 100;

  return (
    <MainLayout>
      <div className="flex-1 space-y-8 p-6 lg:p-8">
        <Reveal className="space-y-4" delay={0}>
          <h1 className="text-4xl font-bold text-white">
            {domainTitle} Learning Roadmap
          </h1>
          <p className="text-muted-foreground">
            Track your progress and stay motivated
          </p>
        </Reveal>

        {/* Progress Section */}
        <Reveal className="rounded-2xl border border-cyan-400/30 bg-gradient-to-r from-cyan-500/20 to-purple-500/10 p-8 backdrop-blur-sm" delay={50}>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Overall Progress</p>
                <p className="text-3xl font-bold text-cyan-400">{Math.round(progress)}%</p>
              </div>
              <div className="text-right">
                <p className="text-sm text-muted-foreground">Completed</p>
                <p className="text-3xl font-bold text-purple-400">
                  {completed.length} / {roadmapSteps.length}
                </p>
              </div>
            </div>
            <div className="h-3 w-full rounded-full bg-white/10">
              <div
                className="h-full rounded-full bg-gradient-to-r from-cyan-400 to-purple-500 transition-all duration-500"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        </Reveal>

        {/* Roadmap Sections */}
        <div className="space-y-8">
          {sections.map((section) => {
            const sectionSteps = roadmapSteps.filter((s) => s.section === section);
            const sectionCompleted = sectionSteps.filter((s) => completed.includes(s.id)).length;

            return (
              <Reveal key={section} className="space-y-4" delay={100}>
                <div className="flex items-center justify-between">
                  <h2 className="text-2xl font-bold text-white">{section}</h2>
                  <span className="text-sm text-muted-foreground">
                    {sectionCompleted} of {sectionSteps.length} completed
                  </span>
                </div>

                <div className="space-y-2">
                  {sectionSteps.map((step) => (
                    <button
                      key={step.id}
                      onClick={() => toggleStep(step.id)}
                      className={`w-full text-left rounded-lg border-2 px-6 py-4 transition duration-200 ${
                        completed.includes(step.id)
                          ? "border-green-400/30 bg-green-500/10"
                          : "border-white/10 bg-gradient-to-br from-white/10 to-white/5 hover:border-cyan-400/50 hover:bg-white/15"
                      }`}
                    >
                      <div className="flex items-start gap-4">
                        <div className="mt-1">
                          {completed.includes(step.id) ? (
                            <CheckCircle2 className="h-5 w-5 text-green-400" />
                          ) : (
                            <Circle className="h-5 w-5 text-white/40" />
                          )}
                        </div>
                        <div className="flex-1">
                          <h3
                            className={`font-semibold transition ${
                              completed.includes(step.id)
                                ? "text-green-400 line-through"
                                : "text-white"
                            }`}
                          >
                            {step.title}
                          </h3>
                          <p className="text-sm text-muted-foreground mt-1">
                            {step.description}
                          </p>
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              </Reveal>
            );
          })}
        </div>
      </div>
    </MainLayout>
  );
}
