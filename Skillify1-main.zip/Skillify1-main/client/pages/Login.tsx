﻿import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Mail, Lock, ArrowRight, CheckCircle, Sparkles } from "lucide-react";
import SkillifyLogo from "@/components/ui/skillify-logo";
import { supabase } from "@/lib/supabase";
import { useToast } from "@/hooks/use-toast";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setIsLoading(true);

    try {
      if (!email || !password) {
        setError("Please fill in all fields");
        return;
      }

      const { data, error: signInError } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (signInError) throw signInError;

      const userName = data.user?.user_metadata?.name || "there";
      toast({
        title: `Welcome back, ${userName}!`,
        description: "You have successfully logged in.",
      });
      navigate("/dashboard");
    } catch (err: any) {
      setError(err.message || "An error occurred. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider: "google",
        options: {
          redirectTo: `${window.location.origin}/dashboard`,
        },
      });
      if (error) throw error;
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Login failed",
        description: error.message || "An unexpected error occurred",
      });
    }
  };

  const features = [
    { icon: Sparkles, text: "AI-Powered Skill Assessment" },
    { icon: CheckCircle, text: "Personalized Learning Paths" },
    { icon: Sparkles, text: "Real-Time Progress Tracking" },
  ];

  return (
    <div className="relative flex min-h-screen bg-background">
      {/* Background Glow */}
      <div className="pointer-events-none fixed inset-0 -z-10 opacity-40 
        [background-image:radial-gradient(circle_at_top_left,rgba(0,255,255,0.12),transparent_45%),
        radial-gradient(circle_at_bottom_right,rgba(127,0,255,0.12),transparent_45%)]" />

      {/* Left Section */}
      <div className="hidden flex-1 flex-col items-start justify-between 
        bg-gradient-to-br from-purple-900/30 via-transparent to-cyan-900/20 p-12 lg:flex">
        <div className="flex items-center gap-3">
          <div className="inline-flex h-12 w-12 items-center justify-center 
            rounded-full border border-white/10 shadow-glow">
            <SkillifyLogo className="h-10 w-10" />
          </div>
          <span className="text-2xl font-bold uppercase tracking-wider text-white">
            Skillify
          </span>
        </div>

        <div className="max-w-sm space-y-8">
          <div className="space-y-4">
            <h2 className="text-4xl font-bold text-white leading-tight">
              Master Any Skill with AI
            </h2>
            <p className="text-lg text-muted-foreground">
              Get personalized learning paths tailored to your goals and progress at your pace.
            </p>
          </div>

          <div className="space-y-4">
            {features.map((feature) => {
              const Icon = feature.icon;
              return (
                <div key={feature.text} className="flex items-center gap-3">
                  <Icon className="h-6 w-6 text-cyan-400 flex-shrink-0" />
                  <span className="text-foreground">{feature.text}</span>
                </div>
              );
            })}
          </div>

          <div className="space-y-3 border-t border-white/10 pt-8">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center 
                rounded-full bg-cyan-400/20 text-cyan-400">

              </div>
              <div>
                <p className="text-sm font-semibold text-white">50K+ Active Learners</p>
                <p className="text-xs text-muted-foreground">Trust Skillify for growth</p>
              </div>
            </div>
          </div>
        </div>

        <p className="text-sm text-muted-foreground">
          2026 Skillify. All rights reserved.
        </p>
      </div>

      {/* Right Section — Form */}
      <div className="flex flex-1 items-center justify-center px-6 py-12 sm:px-12">
        <div className="w-full max-w-md">
          {/* Mobile Logo */}
          <div className="mb-8 flex items-center justify-center lg:hidden">
            <Link to="/" className="flex items-center gap-2 transition hover:opacity-80">
              <div className="inline-flex h-10 w-10 items-center justify-center 
                rounded-full border border-white/10 shadow-glow">
                <SkillifyLogo className="h-8 w-8" />
              </div>
              <span className="text-xl font-bold uppercase tracking-wide text-white">
                Skillify
              </span>
            </Link>
          </div>

          {/* Form Container */}
          <div className="rounded-2xl border border-white/10 bg-gradient-to-br 
            from-white/10 to-white/5 p-4 sm:p-8 backdrop-blur-sm">
            <h1 className="mb-2 text-2xl font-bold text-white">Welcome Back</h1>
            <p className="mb-6 text-muted-foreground">Sign in to your Skillify account</p>

            {error && (
              <div className="mb-4 flex items-center gap-3 rounded-lg border 
                border-red-500/50 bg-red-500/10 p-4 text-sm text-red-400">
                <div className="h-2 w-2 rounded-full bg-red-400" />
                {error}
              </div>
            )}

            <form onSubmit={handleLogin} className="space-y-4">
              {/* Email */}
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-foreground mb-2">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 
                    text-muted-foreground" />
                  <input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="abc@gmail.com"
                    required
                    className="w-full rounded-lg border border-white/10 bg-white/5 
                      py-3 pl-10 pr-4 text-foreground placeholder-muted-foreground 
                      focus:border-cyan-400/50 focus:bg-white/10 focus:outline-none 
                      focus:ring-2 focus:ring-cyan-400/30"
                  />
                </div>
              </div>

              {/* Password */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label htmlFor="password" className="block text-sm font-medium text-foreground">
                    Password
                  </label>

                </div>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 
                    text-muted-foreground" />
                  <input
                    id="password"
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder=""
                    required
                    className="w-full rounded-lg border border-white/10 bg-white/5 
                      py-3 pl-10 pr-4 text-foreground placeholder-muted-foreground 
                      focus:border-cyan-400/50 focus:bg-white/10 focus:outline-none 
                      focus:ring-2 focus:ring-cyan-400/30"
                  />
                </div>
              </div>

              {/* Remember + Forgot */}
              <div className="flex items-center justify-between text-sm">
                <label className="flex items-center gap-2 text-muted-foreground cursor-pointer">
                  <input type="checkbox" className="rounded" />
                  Remember me
                </label>
                <a href="/forgot-password" className="text-xs font-medium text-cyan-400 hover:text-cyan-300">
                  Forgot Password?
                </a>
              </div>

              {/* Submit */}
              <button
                type="submit"
                disabled={isLoading}
                className="btn-glow w-full flex items-center justify-center gap-2 
                  px-6 py-3 text-base font-semibold uppercase tracking-[0.3em] bg-cyan-500 text-white rounded-lg hover:bg-cyan-600 transition-colors"
              >
                {isLoading ? "Signing In..." : "Sign In"}
                {!isLoading && <ArrowRight className="h-4 w-4" />}
              </button>
            </form>

            <div className="my-6 flex items-center gap-4">
              <div className="h-px flex-1 bg-white/10" />
              <span className="text-xs text-muted-foreground">OR</span>
              <div className="h-px flex-1 bg-white/10" />
            </div>

            {/* OAuth */}
            <div className="space-y-3">
              <button
                onClick={handleGoogleLogin}
                type="button"
                className="w-full flex items-center justify-center gap-3 rounded-lg border border-white/10 bg-white/5 
                  px-4 py-3 font-medium text-foreground hover:border-white/30 hover:bg-white/10 transition-colors"
              >
                <svg className="h-5 w-5" viewBox="0 0 24 24">
                  <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" />
                  <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
                  <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05" />
                  <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" />
                  <path d="M1 1h22v22H1z" fill="none" />
                </svg>
                Sign in with Google
              </button>
            </div>
          </div>

          <p className="mt-6 text-center text-sm text-muted-foreground">
            Don't have an account?{" "}
            <Link to="/signup" className="font-semibold text-cyan-400 hover:text-cyan-300">
              Sign up
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}

