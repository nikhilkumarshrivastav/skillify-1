import { useEffect } from "react";

import LandingNavbar from "@/components/landing/LandingNavbar";
import LandingHero from "@/components/landing/LandingHero";
import Features from "@/components/landing/Features";
import HowItWorks from "@/components/landing/HowItWorks";
import Pricing from "@/components/landing/Pricing";
import Testimonials from "@/components/landing/Testimonials";
import FAQ from "@/components/landing/FAQ";
import LandingAbout from "@/components/landing/LandingAbout";
import LandingFooter from "@/components/landing/LandingFooter";
import ScrollProgressBar from "@/components/ui/scroll-progress-bar";
import ScrollToTopButton from "@/components/ui/scroll-to-top";

export default function Index() {

  // ⭐ SCROLL ANIMATION LOGIC — safe, no plugin errors
  useEffect(() => {
    const handleScroll = () => {
      const elements = document.querySelectorAll(".fade-in-element");
      elements.forEach((el) => {
        const rect = el.getBoundingClientRect();
        if (rect.top < window.innerHeight * 0.9) {
          el.classList.add("fade-in-visible");
        }
      });
    };

    window.addEventListener("scroll", handleScroll);
    handleScroll(); // run immediately

    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div className="relative flex min-h-screen flex-col overflow-hidden">
      <div className="pointer-events-none fixed inset-0 -z-10 opacity-40
        [background-image:radial-gradient(circle_at_top_left,rgba(0,255,255,0.12),transparent_45%),
        radial-gradient(circle_at_bottom_right,rgba(127,0,255,0.12),transparent_45%)]" 
      />

      <ScrollProgressBar />
      <LandingNavbar />

      <main className="relative z-10 flex-1 pt-16 sm:pt-20">
        <LandingHero />
        <Features />
        <HowItWorks />
        <Pricing />
        <Testimonials />
        <FAQ />
        <LandingAbout />
      </main>

      <LandingFooter />
      <ScrollToTopButton />
    </div>
  );
}
