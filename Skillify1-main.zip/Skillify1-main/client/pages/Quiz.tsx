import QuizLoader from "@/components/loader/QuizLoader";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import MainLayout from "@/components/layout/MainLayout";
import { ChevronRight, ChevronLeft } from "lucide-react";

// ----------------------
// Type Definitions
// ----------------------
type Question = {
  id: number;
  question: string;
  options: string[];
  answer: string;
};

// ----------------------
// Component
// ----------------------
export default function Quiz() {
  const navigate = useNavigate();

  const [questions, setQuestions] = useState<Question[]>([]);
  const [loading, setLoading] = useState(true); // loader screen
  const [transition, setTransition] = useState(false);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [answers, setAnswers] = useState<number[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const selectedDomain =
    localStorage.getItem("selected_domain") || "machine-learning";
  const programmingExp =
    localStorage.getItem("programming_exp") || "beginner";
  const pastExperience =
    localStorage.getItem("past_experience") || "none";

  // ----------------------
  // Fetching Questions from FastAPI
  // ----------------------
  useEffect(() => {
    async function loadQuestions() {
      try {
        const backendTech = localStorage.getItem("backend_tech");

        const res = await fetch("http://127.0.0.1:8000/get-quiz", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            domain: selectedDomain,
            programming_exp: programmingExp,
            past_experience: pastExperience,
            backend_tech: backendTech,
          }),
        });

        if (!res.ok) {
          alert("❌ Backend error while fetching questions.");
          setLoading(false);
          return;
        }

        const data = await res.json();

        if (!data || !data.questions || data.questions.length === 0) {
          alert("⚠ No questions received from backend. Check generate_questions.py");
          setLoading(false);
          return;
        }

        setQuestions(data.questions);

        // SHOW LOADER FOR 12 SECONDS
        setTimeout(() => setLoading(false), 12000);
      } catch (err) {
        alert("❌ Error loading quiz. Check backend connection.");
        setLoading(false);
      }
    }

    loadQuestions();
  }, []);

  // ----------------------
  // Select Option
  // ----------------------
  const handleSelect = (index: number) => {
    setSelectedAnswer(index);
  };

  // ----------------------
  // Next Question
  // ----------------------
  const handleNext = () => {
    if (selectedAnswer === null)
      return alert("Please select an answer before continuing.");

    const updatedAnswers = [...answers];
    updatedAnswers[currentQuestion] = selectedAnswer;
    setAnswers(updatedAnswers);

    if (currentQuestion < questions.length - 1) {
      setTransition(true);
      setTimeout(() => {
        setCurrentQuestion((q) => q + 1);
        setSelectedAnswer(null);
        setTransition(false);
      }, 300);
    } else {
      const evaluatedAnswers = updatedAnswers.map((ans, i) => {
        return questions[i].options[ans] === questions[i].answer ? 1 : 0;
      });

      handleSubmit(evaluatedAnswers);
    }
  };

  // ----------------------
  // Previous Question
  // ----------------------
  const handlePrevious = () => {
    if (currentQuestion === 0) return;

    setTransition(true);
    setTimeout(() => {
      setCurrentQuestion((q) => q - 1);
      setSelectedAnswer(answers[currentQuestion - 1] ?? null);
      setTransition(false);
    }, 300);
  };

  // ----------------------
  // Submit to FastAPI
  // ----------------------
  const handleSubmit = async (finalAnswers: number[]) => {
    setIsSubmitting(true);

    try {
      const res = await fetch("http://127.0.0.1:8000/analyze-quiz", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          answers: finalAnswers,
          domain: selectedDomain,
        }),
      });

      const data = await res.json();

      localStorage.setItem("last_quiz_score", data.score);
      localStorage.setItem("skill_level", data.level);
      localStorage.setItem("strengths", JSON.stringify(data.strengths));
      localStorage.setItem("weaknesses", JSON.stringify(data.weaknesses));

      navigate("/results");
    } catch (err) {
      alert("❌ Error submitting quiz.");
    }

    setIsSubmitting(false);
  };

  const question = questions[currentQuestion];
  const progress =
    questions.length > 0
      ? ((currentQuestion + 1) / questions.length) * 100
      : 0;

  // ----------------------
  // Loader Screen
  // ----------------------
  if (loading) {
    return <QuizLoader onComplete={() => setLoading(false)} />;
  }

  // ----------------------
  // Prevent crash if questions missing
  // ----------------------
  if (questions.length === 0) {
    return (
      <MainLayout>
        <div className="flex flex-col items-center justify-center h-full text-white text-xl">
          ❌ No quiz questions available.
        </div>
      </MainLayout>
    );
  }

  // ----------------------
  // Quiz UI
  // ----------------------
  return (
    <MainLayout>
      <div className="flex-1 space-y-6 p-6">
        {/* Progress */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-white">Quiz</h1>
            <p className="text-muted-foreground">
              Question {currentQuestion + 1}/{questions.length}
            </p>
          </div>

          <div className="text-right">
            <div className="text-sm font-semibold text-cyan-400 mb-2">
              {Math.round(progress)}%
            </div>
            <div className="h-2 w-48 bg-white/10 rounded-full">
              <div
                className="h-full rounded-full bg-gradient-to-r from-cyan-400 to-purple-500 transition-all"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        </div>

        {/* Question Card */}
        <div
          className={`rounded-2xl border border-white/10 bg-white/5 p-8 transition-all duration-300 ${transition ? "opacity-0 translate-x-3" : "opacity-100 translate-x-0"
            }`}
        >
          <h2 className="text-2xl font-bold text-white mb-6">
            {question.question}
          </h2>

          {/* Options */}
          <div className="space-y-3">
            {question.options.map((opt, idx) => (
              <button
                key={idx}
                onClick={() => handleSelect(idx)}
                className={`w-full text-left rounded-lg border-2 px-6 py-4 transition ${selectedAnswer === idx
                  ? "border-cyan-400 bg-cyan-500/20"
                  : "border-white/10 bg-white/5 hover:bg-white/10"
                  }`}
              >
                {opt}
              </button>
            ))}
          </div>

          {/* Navigation */}
          <div className="flex gap-4 mt-6">
            <button
              onClick={handlePrevious}
              disabled={currentQuestion === 0}
              className="flex items-center gap-2 px-6 py-3 rounded-lg bg-white/5 border border-white/10 text-white disabled:opacity-40"
            >
              <ChevronLeft className="h-4 w-4" />
              Previous
            </button>

            <button
              onClick={handleNext}
              disabled={isSubmitting}
              className="flex-1 flex items-center justify-center gap-2 px-6 py-3 rounded-lg bg-cyan-500/30 text-white font-semibold shadow-lg"
            >
              {isSubmitting
                ? "Submitting..."
                : currentQuestion === questions.length - 1
                  ? "Submit"
                  : "Next"}

              {!isSubmitting && <ChevronRight className="h-4 w-4" />}
            </button>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
