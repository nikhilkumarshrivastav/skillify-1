import Reveal from "@/components/ui/reveal";
import { Star } from "lucide-react";

const Testimonials = () => {
  const testimonials = [
    {
      name: "Nikhil Kumar Shrivastav",
      position: "Software Engineer",
      content: "Skillify's AI recommendations helped me transition careers. The personalized roadmap saved me months of research and confusion.",
      rating: 5,
      avatar: "NS",
    },
    {
      name: "Karan Kawle",
      position: "Student",
      content: "I was lost trying to learn data science. Skillify's quizzes identified my gaps and gave me exactly what I needed to focus on.",
      rating: 5,
      avatar: "KK",
    },
    {
      name: "Varad Kulkarni",
      position: "Product Manager",
      content: "The personalized learning paths are incredible. Tracking progress has never been easier, and I actually stick to the plan!",
      rating: 5,
      avatar: "VK",
    },
    {
      name: "Vinayak Khade",
      position: "Freelance Designer",
      content: "Best investment I made for my learning journey. The AI is surprisingly accurate at assessing my skills and recommending resources.",
      rating: 5,
      avatar: "VK",
    },
  ];

  return (
    <section id="testimonials" className="relative w-full px-6 py-20 lg:px-20">
      <div className="absolute inset-0 -z-10">
        <div className="absolute right-0 bottom-1/3 h-[400px] w-[400px] rounded-full bg-gradient-to-l from-purple-500/20 to-transparent blur-3xl" />
      </div>

      <div className="mx-auto flex w-full max-w-full flex-col items-center">
        <Reveal className="mb-16 text-center" delay={0}>
          <h2 className="text-3xl font-bold sm:text-4xl lg:text-5xl">What Our Users Say</h2>
          <p className="mt-4 text-lg text-muted-foreground">Join thousands of satisfied learners.</p>
        </Reveal>

        <div className="grid w-full grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-4 lg:max-w-7xl">
          {testimonials.map((testimonial, index) => (
            <Reveal
              key={testimonial.name}
              className="flex flex-col gap-4 rounded-2xl border border-white/10 bg-gradient-to-br from-white/10 to-white/5 p-6 backdrop-blur-sm transition duration-300 ease-out hover:border-cyan-400/50 hover:bg-white/15 hover:-translate-y-2 hover:shadow-lg hover:shadow-cyan-500/20"
              delay={index * 100}
            >
              <div className="flex gap-1">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                ))}
              </div>
              <p className="text-foreground">{testimonial.content}</p>
              <div className="flex items-center gap-3 border-t border-white/10 pt-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-cyan-400 to-purple-500 text-sm font-bold text-white">
                  {testimonial.avatar}
                </div>
                <div>
                  <p className="text-sm font-semibold text-white">{testimonial.name}</p>
                  <p className="text-xs text-muted-foreground">{testimonial.position}</p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
