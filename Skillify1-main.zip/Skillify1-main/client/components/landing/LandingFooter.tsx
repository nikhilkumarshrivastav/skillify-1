import { Github, Linkedin, Mail, ArrowUp } from "lucide-react";

const LandingFooter = () => {
  const handleScrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <footer className="relative w-full border-t border-white/10 bg-gradient-to-b from-transparent via-white/5 to-white/10">
      <div className="mx-auto w-full px-6 py-16 lg:px-20">
        <div className="flex w-full max-w-full flex-col gap-12 lg:flex-row lg:items-start lg:justify-between lg:gap-8">
          {/* Brand and Social */}
          <div className="flex max-w-sm flex-col gap-6">
            <div className="flex items-center gap-2">
              <span className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-gradient-to-br from-cyan-400 to-purple-500 text-lg font-bold text-white shadow-glow">
                S
              </span>
              <span className="text-lg font-bold uppercase tracking-wide text-white">Skillify</span>
            </div>
            <p className="text-sm text-muted-foreground">
              AI-powered learning platform that personalizes your educational journey.
            </p>
            <div className="flex items-center gap-4">
              <a
                href="#"
                className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-white/15 bg-white/5 text-foreground/80 backdrop-blur-md transition hover:border-cyan-400/60 hover:text-cyan-400"
                aria-label="GitHub"
              >
                <Github className="h-5 w-5" />
              </a>
              <a
                href="#"
                className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-white/15 bg-white/5 text-foreground/80 backdrop-blur-md transition hover:border-purple-400/60 hover:text-purple-400"
                aria-label="LinkedIn"
              >
                <Linkedin className="h-5 w-5" />
              </a>
              <a
                href="#"
                className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-white/15 bg-white/5 text-foreground/80 backdrop-blur-md transition hover:border-cyan-400/60 hover:text-cyan-400"
                aria-label="Email"
              >
                <Mail className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="flex flex-col gap-4">
            <h4 className="text-sm font-semibold uppercase tracking-wider text-white">Product</h4>
            <nav className="flex flex-col gap-2">
              <a href="#features" className="text-sm text-muted-foreground transition hover:text-cyan-400">
                Features
              </a>
              <a href="#pricing" className="text-sm text-muted-foreground transition hover:text-cyan-400">
                Pricing
              </a>
              <a href="#how-it-works" className="text-sm text-muted-foreground transition hover:text-cyan-400">
                How It Works
              </a>
            </nav>
          </div>

          {/* Company Links */}
          <div className="flex flex-col gap-4">
            <h4 className="text-sm font-semibold uppercase tracking-wider text-white">Company</h4>
            <nav className="flex flex-col gap-2">
              <a href="#about" className="text-sm text-muted-foreground transition hover:text-cyan-400">
                About
              </a>
              <a href="#" className="text-sm text-muted-foreground transition hover:text-cyan-400">
                Contact
              </a>
              <a href="#" className="text-sm text-muted-foreground transition hover:text-cyan-400">
                Blog
              </a>
            </nav>
          </div>

          {/* Legal Links */}
          <div className="flex flex-col gap-4">
            <h4 className="text-sm font-semibold uppercase tracking-wider text-white">Legal</h4>
            <nav className="flex flex-col gap-2">
              <a href="#" className="text-sm text-muted-foreground transition hover:text-cyan-400">
                Terms of Service
              </a>
              <a href="#" className="text-sm text-muted-foreground transition hover:text-cyan-400">
                Privacy Policy
              </a>
              <a href="#" className="text-sm text-muted-foreground transition hover:text-cyan-400">
                Cookie Policy
              </a>
            </nav>
          </div>

          {/* Scroll to Top */}
          <button
            type="button"
            onClick={handleScrollToTop}
            className="flex h-12 w-12 items-center justify-center rounded-full border border-white/15 bg-white/5 text-foreground/80 backdrop-blur-md transition hover:-translate-y-1 hover:border-cyan-400/60 hover:text-cyan-400"
            aria-label="Scroll to top"
          >
            <ArrowUp className="h-5 w-5" />
          </button>
        </div>

        {/* Bottom Section */}
        <div className="mt-12 border-t border-white/10 pt-8">
          <div className="flex flex-col items-center justify-between gap-4 sm:flex-row">
            <p className="text-sm text-muted-foreground">© 2025 Skillify. All rights reserved.</p>
            <div className="flex gap-4 text-sm text-muted-foreground">
              <span>Made with ❤️ by Skillify Team</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default LandingFooter;
