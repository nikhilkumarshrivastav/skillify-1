import ThemeToggle from "@/components/ui/theme-toggle";
import SkillifyLogo from "@/components/ui/skillify-logo";
import { cn } from "@/lib/utils";
import { Menu, X } from "lucide-react";
import { useEffect, useMemo, useState, type MouseEvent } from "react";
import { useNavigate } from "react-router-dom";

type NavItem = {
  id: string;
  label: string;
};

const NAV_ITEMS: NavItem[] = [
  { id: "home", label: "Home" },
  { id: "features", label: "Features" },
  { id: "how-it-works", label: "How It Works" },
  { id: "pricing", label: "Pricing" },
  { id: "testimonials", label: "Testimonials" },
  { id: "faq", label: "FAQ" },
  { id: "about", label: "About" },
];

const LandingNavbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState<string>(NAV_ITEMS[0]?.id ?? "home");
  const navigate = useNavigate();

  const sectionIds = useMemo(() => NAV_ITEMS.map((item) => item.id), []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];

        if (visible?.target?.id) {
          setActiveSection(visible.target.id);
        }
      },
      { threshold: 0.4 }
    );

    sectionIds.forEach((id) => {
      const element = document.getElementById(id);
      if (element) {
        observer.observe(element);
      }
    });

    return () => {
      observer.disconnect();
    };
  }, [sectionIds]);

  useEffect(() => {
    if (!isMenuOpen) {
      return;
    }

    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setIsMenuOpen(false);
      }
    };

    window.addEventListener("keydown", handleEscape);
    return () => window.removeEventListener("keydown", handleEscape);
  }, [isMenuOpen]);

  const handleNavigate = (event: MouseEvent<HTMLAnchorElement>, id: string) => {
    event.preventDefault();
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
      setActiveSection(id);
    }
    setIsMenuOpen(false);
  };

  const handleSignIn = () => {
    navigate("/login");
  };

  const handleGetStarted = () => {
    navigate("/signup");
  };

  return (
    <header className="fixed inset-x-0 top-0 z-40 flex justify-center w-full">
      <nav className="glassy-nav relative flex w-full flex-col items-center justify-center px-4 py-3 shadow-glass-lg sm:flex-row sm:justify-between sm:px-8 sm:py-4 rounded-none sm:rounded-b-2xl">
        {/* Logo and Menu Toggle */}
        <div className="flex w-full items-center justify-between sm:w-auto sm:justify-start">
          <a
            href="#home"
            onClick={(event) => handleNavigate(event, "home")}
            className="relative flex items-center gap-2 text-base font-semibold tracking-tight text-foreground transition hover:opacity-80"
          >
            <div className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-white/10 shadow-glow">
              <SkillifyLogo className="h-8 w-8" />
            </div>
            <span className="hidden text-lg font-bold uppercase tracking-wide text-white sm:inline">Skillify</span>
          </a>

          {/* Mobile Menu Button */}
          <button
            type="button"
            onClick={() => setIsMenuOpen((prev) => !prev)}
            className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-white/15 bg-white/5 text-foreground/80 backdrop-blur-md transition hover:-translate-y-0.5 hover:border-accent/60 hover:text-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/70 sm:hidden"
            aria-expanded={isMenuOpen}
            aria-label="Toggle navigation menu"
          >
            {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>

        {/* Desktop Menu */}
        <div className="hidden items-center gap-2 sm:flex">
          {NAV_ITEMS.map((item) => (
            <a
              key={item.id}
              href={`#${item.id}`}
              onClick={(event) => handleNavigate(event, item.id)}
              className={cn("underline-link text-sm", {
                active: activeSection === item.id,
              })}
            >
              {item.label}
            </a>
          ))}
        </div>

        {/* Desktop Buttons */}
        <div className="hidden items-center gap-3 sm:flex">
          <button
            type="button"
            onClick={handleSignIn}
            className="px-4 py-2 text-sm font-semibold text-foreground transition hover:text-accent"
          >
            Sign In
          </button>
          <button
            type="button"
            onClick={handleGetStarted}
            className="btn-glow px-5 py-2 text-xs font-semibold uppercase tracking-[0.3em] shadow-glow"
          >
            Get Started
          </button>
          <ThemeToggle />
        </div>
      </nav>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="glassy-nav absolute top-16 left-0 right-0 z-40 w-full rounded-none px-4 py-4 sm:hidden">
          <div className="flex flex-col gap-2">
            {NAV_ITEMS.map((item) => (
              <a
                key={item.id}
                href={`#${item.id}`}
                onClick={(event) => handleNavigate(event, item.id)}
                className={cn(
                  "underline-link w-full justify-start rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm",
                  {
                    active: activeSection === item.id,
                  }
                )}
              >
                {item.label}
              </a>
            ))}
            <div className="border-t border-white/10 pt-2 mt-2 flex flex-col gap-2">
              <button
                type="button"
                onClick={() => {
                  setIsMenuOpen(false);
                  handleSignIn();
                }}
                className="w-full rounded-full border border-white/15 bg-white/5 px-5 py-3 text-sm font-semibold text-foreground backdrop-blur-md transition hover:border-accent/60 hover:text-accent"
              >
                Sign In
              </button>
              <button
                type="button"
                onClick={() => {
                  setIsMenuOpen(false);
                  handleGetStarted();
                }}
                className="btn-glow w-full rounded-full px-5 py-3 text-sm font-semibold uppercase tracking-[0.3em]"
              >
                Get Started
              </button>
            </div>
            <div className="flex justify-center border-t border-white/10 pt-2 mt-2">
              <ThemeToggle />
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

export default LandingNavbar;
