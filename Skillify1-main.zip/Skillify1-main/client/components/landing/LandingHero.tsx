import Reveal from "@/components/ui/reveal";
import { useNavigate } from "react-router-dom";

const LandingHero = () => {
  const navigate = useNavigate();

  return (
    <section id="home" className="relative min-h-[calc(100vh-100px)] w-full overflow-hidden pt-32">
      <div className="absolute inset-0 -z-10">
        <div className="absolute left-0 top-1/4 h-[500px] w-[500px] rounded-full bg-gradient-to-r from-cyan-500/30 to-transparent blur-3xl" />
        <div className="absolute right-0 top-1/2 h-[400px] w-[400px] rounded-full bg-gradient-to-l from-purple-500/20 to-transparent blur-3xl" />
      </div>

      <div className="mx-auto flex w-full max-w-full flex-col items-center justify-center gap-8 px-6 py-20 lg:px-20">
        <Reveal className="flex flex-col items-center gap-6 text-center" delay={0}>
          <h1 className="text-4xl font-bold leading-tight sm:text-5xl lg:text-6xl xl:text-7xl">
            <span className="bg-gradient-to-r from-cyan-400 via-cyan-300 to-purple-500 bg-clip-text text-transparent">
              Learn Smarter.
            </span>
            <br />
            <span className="text-white">Progress Faster.</span>
          </h1>
        </Reveal>

        <Reveal className="max-w-3xl text-center text-lg text-muted-foreground sm:text-xl" delay={100}>
          <p>
            Skillify analyzes your skills with AI and builds a personalized learning roadmap so you know exactly where to start and what to learn next.
          </p>
        </Reveal>

        <Reveal className="flex flex-col gap-4 sm:flex-row sm:justify-center" delay={200}>
          <button
            type="button"
            onClick={() => navigate("/signup")}
            className="btn-glow px-8 py-4 text-base font-semibold uppercase tracking-wider shadow-glow transition hover:shadow-glow hover:scale-105"
          >
            Get Started
          </button>
          <button
            type="button"
            className="flex items-center justify-center gap-2 rounded-xl border border-white/20 bg-white/5 px-8 py-4 text-base font-semibold text-white backdrop-blur-md transition hover:border-accent/60 hover:bg-white/10 hover:text-accent"
          >
            <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 20 20">
              <path d="M6.3 2.841A1.5 1.5 0 004 4.11V15.89a1.5 1.5 0 002.3 1.269l9.344-5.89a1.5 1.5 0 000-2.538L6.3 2.84z" />
            </svg>
            Watch Demo
          </button>
        </Reveal>

        <Reveal className="mt-16 grid w-full grid-cols-1 gap-8 px-4 sm:grid-cols-3 lg:px-0 lg:max-w-5xl" delay={300}>
          <div className="flex flex-col items-center gap-3 rounded-xl border border-white/10 bg-white/5 p-6 backdrop-blur-sm transition hover:border-cyan-400/50 hover:bg-white/10">
            <div className="text-4xl font-bold text-cyan-400">98%</div>
            <p className="text-center text-sm text-muted-foreground">Students improved accuracy</p>
          </div>
          <div className="flex flex-col items-center gap-3 rounded-xl border border-white/10 bg-white/5 p-6 backdrop-blur-sm transition hover:border-purple-400/50 hover:bg-white/10">
            <div className="text-4xl font-bold text-purple-400">50K+</div>
            <p className="text-center text-sm text-muted-foreground">Active learners worldwide</p>
          </div>
          <div className="flex flex-col items-center gap-3 rounded-xl border border-white/10 bg-white/5 p-6 backdrop-blur-sm transition hover:border-cyan-400/50 hover:bg-white/10">
            <div className="text-4xl font-bold text-cyan-400">4.9★</div>
            <p className="text-center text-sm text-muted-foreground">Average user rating</p>
          </div>
        </Reveal>
      </div>
    </section>
  );
};

export default LandingHero;
