import Reveal from "@/components/ui/reveal";
import { Zap, Target, Brain, TrendingUp } from "lucide-react";

const Features = () => {
  const features = [
    {
      icon: Brain,
      title: "AI Skill Analysis",
      description: "Our advanced AI analyzes your current skills and knowledge gaps with precision.",
    },
    {
      icon: Target,
      title: "Personalized Learning",
      description: "Get customized learning paths tailored to your goals and learning style.",
    },
    {
      icon: Zap,
      title: "Smart Quizzes",
      description: "Interactive quizzes powered by AI to evaluate your knowledge effectively.",
    },
    {
      icon: TrendingUp,
      title: "Progress Tracking",
      description: "Monitor your progress with detailed analytics and performance insights.",
    },
  ];

  return (
    <section id="features" className="relative w-full px-6 py-20 lg:px-20">
      <div className="mx-auto flex w-full max-w-full flex-col items-center">
        <Reveal className="mb-16 text-center" delay={0}>
          <h2 className="text-3xl font-bold sm:text-4xl lg:text-5xl">Key Features</h2>
          <p className="mt-4 text-lg text-muted-foreground">Everything you need for smarter learning.</p>
        </Reveal>

        <div className="grid w-full grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-4 lg:max-w-7xl">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <Reveal
                key={feature.title}
                className="group relative flex flex-col gap-4 rounded-2xl border border-white/10 bg-gradient-to-br from-white/10 to-white/5 p-8 backdrop-blur-sm transition duration-300 ease-out hover:border-cyan-400/50 hover:bg-white/15 hover:-translate-y-2 hover:shadow-lg hover:shadow-cyan-500/20"
                delay={index * 100}
              >
                <div className="inline-flex h-14 w-14 items-center justify-center rounded-xl bg-gradient-to-br from-cyan-500/30 to-purple-500/30 text-cyan-400 transition duration-300 ease-out group-hover:from-cyan-500/50 group-hover:to-purple-500/50 group-hover:text-cyan-300 group-hover:scale-110">
                  <Icon className="h-7 w-7" />
                </div>
                <h3 className="text-xl font-semibold text-white transition duration-300">{feature.title}</h3>
                <p className="text-muted-foreground transition duration-300">{feature.description}</p>
                <div className="absolute inset-0 rounded-2xl opacity-0 transition duration-300 ease-out group-hover:opacity-100 -z-10 bg-gradient-to-br from-cyan-500/10 to-purple-500/10 blur-xl" />
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Features;
