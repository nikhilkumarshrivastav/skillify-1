import Reveal from "@/components/ui/reveal";
import { Brain, Lightbulb, Rocket } from "lucide-react";

const LandingAbout = () => {
  const highlights = [
    {
      icon: Brain,
      title: "AI-Powered Assessment",
      description: "Advanced AI evaluates your skills accurately and comprehensively",
    },
    {
      icon: Lightbulb,
      title: "Smart Recommendations",
      description: "Personalized learning paths based on your unique profile and goals",
    },
    {
      icon: Rocket,
      title: "Rapid Progress",
      description: "Learn efficiently with resources curated specifically for you",
    },
  ];

  return (
    <section id="about" className="relative w-full px-6 py-20 lg:px-20">
      <div className="absolute inset-0 -z-10">
        <div className="absolute right-1/3 top-1/4 h-[500px] w-[500px] rounded-full bg-gradient-to-l from-cyan-500/15 to-transparent blur-3xl" />
      </div>

      <div className="mx-auto flex w-full max-w-full flex-col items-center">
        <Reveal className="mb-12 max-w-3xl text-center" delay={0}>
          <h2 className="text-3xl font-bold sm:text-4xl lg:text-5xl">About Skillify</h2>
          <p className="mt-6 text-lg text-foreground">
            Skillify helps students and professionals discover their skill level, identify their strengths and weaknesses
            through AI-powered quizzes, and receive personalized roadmaps to learn any chosen domain effectively.
          </p>
        </Reveal>

        <div className="grid w-full grid-cols-1 gap-8 md:grid-cols-3 lg:max-w-7xl">
          {highlights.map((highlight, index) => {
            const Icon = highlight.icon;
            return (
              <Reveal
                key={highlight.title}
                className="flex flex-col gap-4 rounded-2xl border border-white/10 bg-gradient-to-br from-white/10 to-white/5 p-8 text-center backdrop-blur-sm transition hover:border-cyan-400/50 hover:bg-white/15"
                delay={index * 100}
              >
                <div className="flex justify-center">
                  <div className="inline-flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-cyan-500/30 to-purple-500/30 text-cyan-400">
                    <Icon className="h-8 w-8" />
                  </div>
                </div>
                <h3 className="text-xl font-semibold text-white">{highlight.title}</h3>
                <p className="text-muted-foreground">{highlight.description}</p>
              </Reveal>
            );
          })}
        </div>

        <Reveal className="mt-16 text-center" delay={300}>
          <div className="rounded-2xl border border-white/10 bg-gradient-to-br from-cyan-500/10 to-purple-500/10 p-8 backdrop-blur-sm">
            <h3 className="text-2xl font-bold text-white">Our Mission</h3>
            <p className="mt-4 text-lg text-foreground">
              We believe every learner deserves a personalized education experience. By combining cutting-edge AI with proven learning science,
              Skillify empowers students and professionals to learn smarter, progress faster, and achieve their goals.
            </p>
          </div>
        </Reveal>
      </div>
    </section>
  );
};

export default LandingAbout;
