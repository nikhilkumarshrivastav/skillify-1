import Reveal from "@/components/ui/reveal";
import { useRef, useState } from "react";
import { ChevronDown } from "lucide-react";

const FAQ = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);
  const contentRefs = useRef<(HTMLDivElement | null)[]>([]);

  const faqs = [
    {
      question: "How does Skillify's AI assessment work?",
      answer:
        "Skillify uses advanced AI algorithms to analyze your responses to our intelligent quizzes. We evaluate not just your answers, but your reasoning patterns to accurately assess your skill level and identify knowledge gaps.",
    },
    {
      question: "Can I change my learning path after starting?",
      answer:
        "Absolutely! Your learning path is flexible and can be adjusted at any time. As you progress and your goals evolve, Skillify will update your recommendations to match your changing needs.",
    },
    {
      question: "How often are the learning recommendations updated?",
      answer:
        "Your recommendations are updated in real-time as you complete quizzes and learn new material. We continuously refine your path based on your performance and feedback.",
    },
    {
      question: "Is my data private and secure?",
      answer:
        "Yes, we take privacy and security seriously. All your data is encrypted and stored securely. We never share your personal information with third parties without your explicit consent.",
    },
    {
      question: "What if I have technical issues?",
      answer:
        "Our support team is here to help! Pro and Ultimate plan members get priority support. You can reach out via email or our in-app support chat, and we'll resolve issues quickly.",
    },
    {
      question: "Can I use Skillify on mobile devices?",
      answer:
        "Yes! Skillify is fully responsive and works seamlessly on mobile, tablet, and desktop devices. Pro and Ultimate plans also include offline access for uninterrupted learning.",
    },
    {
      question: "Is there a free trial available?",
      answer:
        "Yes! You can start with our free Basic plan to explore Skillify's features. Pro and Ultimate plans offer a 14-day free trial so you can experience the full platform before committing.",
    },
  ];

  return (
    <section id="faq" className="relative w-full px-6 py-20 lg:px-20">
      <div className="absolute inset-0 -z-10">
        <div className="absolute left-1/4 bottom-0 h-[400px] w-[400px] rounded-full bg-gradient-to-t from-cyan-500/20 to-transparent blur-3xl" />
      </div>

      <div className="mx-auto flex w-full max-w-full flex-col items-center">
        <Reveal className="mb-16 text-center" delay={0}>
          <h2 className="text-3xl font-bold sm:text-4xl lg:text-5xl">Frequently Asked Questions</h2>
          <p className="mt-4 text-lg text-muted-foreground">Find answers to common questions about Skillify.</p>
        </Reveal>

        <div className="w-full space-y-4 lg:max-w-3xl">
          {faqs.map((faq, index) => (
            <Reveal key={faq.question} delay={index * 50}>
              <button
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="w-full text-left rounded-lg border border-white/10 bg-gradient-to-br from-white/10 to-white/5 p-6 transition hover:border-cyan-400/50 hover:bg-white/15"
              >
                <div className="flex items-center justify-between gap-4">
                  <h3 className="text-lg font-semibold text-white">{faq.question}</h3>
                  <ChevronDown
                    className={`h-5 w-5 flex-shrink-0 text-cyan-400 transition-all duration-400 ${
                      openIndex === index ? "rotate-180" : ""
                    }`}
                  />
                </div>
              </button>
              <div
              className={`overflow-hidden transition-all duration-500 ease-out ${
                openIndex === index ? "max-h-96 opacity-100" : "max-h-0 opacity-0"
              }`}
            >
              <div
                ref={(el) => {
                  contentRefs.current[index] = el;
                }}
                className="border-t border-white/10 bg-gradient-to-br from-white/5 to-transparent px-6 py-4 text-foreground rounded-b-lg"
              >
                <p>{faq.answer}</p>
              </div>
            </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FAQ;
