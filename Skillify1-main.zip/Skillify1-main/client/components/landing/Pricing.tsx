import Reveal from "@/components/ui/reveal";
import { Check } from "lucide-react";
import { useNavigate } from "react-router-dom";

const Pricing = () => {
  const navigate = useNavigate();

  const plans = [
    {
      name: "Basic",
      price: "Free",
      description: "Perfect for getting started",
      features: [
        "AI Skill Assessment",
        "Basic Learning Roadmap",
        "Limited Quizzes (5/month)",
        "Progress Dashboard",
        "Email Support",
      ],
      cta: "Get Started",
      highlighted: false,
    },
    {
      name: "Pro",
      price: "$9.99",
      period: "/month",
      description: "Best for serious learners",
      features: [
        "Everything in Basic",
        "Unlimited Quizzes",
        "Advanced Analytics",
        "Personalized Recommendations",
        "Priority Support",
        "Offline Access",
      ],
      cta: "Start Free Trial",
      highlighted: true,
    },
    {
      name: "Ultimate",
      price: "$24.99",
      period: "/month",
      description: "For power users",
      features: [
        "Everything in Pro",
        "1-on-1 Mentorship",
        "Custom Learning Plans",
        "API Access",
        "Team Collaboration",
        "24/7 Dedicated Support",
      ],
      cta: "Contact Sales",
      highlighted: false,
    },
  ];

  return (
    <section id="pricing" className="relative w-full px-6 py-20 lg:px-20">
      <div className="absolute inset-0 -z-10">
        <div className="absolute left-1/3 top-0 h-[400px] w-[400px] rounded-full bg-gradient-to-b from-cyan-500/20 to-transparent blur-3xl" />
      </div>

      <div className="mx-auto flex w-full max-w-full flex-col items-center">
        <Reveal className="mb-16 text-center" delay={0}>
          <h2 className="text-3xl font-bold sm:text-4xl lg:text-5xl">Simple, Transparent Pricing</h2>
          <p className="mt-4 text-lg text-muted-foreground">Choose the plan that works best for you.</p>
        </Reveal>

        <div className="grid w-full grid-cols-1 gap-8 md:grid-cols-3 lg:max-w-7xl">
          {plans.map((plan, index) => (
            <Reveal
              key={plan.name}
              className={`relative flex flex-col gap-6 rounded-2xl border p-8 backdrop-blur-sm transition duration-300 ease-out ${
                plan.highlighted
                  ? "border-cyan-400/50 bg-gradient-to-br from-cyan-500/20 to-purple-500/10 ring-1 ring-cyan-400/30 hover:-translate-y-2 hover:shadow-lg hover:shadow-cyan-500/30"
                  : "border-white/10 bg-gradient-to-br from-white/10 to-white/5 hover:border-cyan-400/30 hover:bg-white/15 hover:-translate-y-2 hover:shadow-lg hover:shadow-white/10"
              }`}
              delay={index * 100}
            >
              {plan.highlighted && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 rounded-full bg-gradient-to-r from-cyan-400 to-purple-500 px-4 py-1 text-sm font-semibold text-white">
                  Most Popular
                </div>
              )}

              <div>
                <h3 className="text-2xl font-bold text-white">{plan.name}</h3>
                <p className="mt-2 text-muted-foreground">{plan.description}</p>
              </div>

              <div>
                <span className="text-4xl font-bold text-white">{plan.price}</span>
                {plan.period && <span className="text-muted-foreground">{plan.period}</span>}
              </div>

              <button
                type="button"
                onClick={() => navigate("/signup")}
                className={`w-full rounded-lg px-6 py-3 font-semibold transition ${
                  plan.highlighted
                    ? "btn-glow shadow-glow"
                    : "border border-white/20 bg-white/5 text-white hover:border-accent/60 hover:bg-white/10 hover:text-accent"
                }`}
              >
                {plan.cta}
              </button>

              <div className="border-t border-white/10" />

              <ul className="flex flex-col gap-3">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-center gap-3">
                    <Check className="h-5 w-5 text-cyan-400" />
                    <span className="text-sm text-foreground">{feature}</span>
                  </li>
                ))}
              </ul>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Pricing;
