import Reveal from "@/components/ui/reveal";
import { CheckCircle2 } from "lucide-react";

const HowItWorks = () => {
  const steps = [
    {
      number: "01",
      title: "Take the Quiz",
      description: "Start with our AI-powered assessment to evaluate your current skill level and knowledge.",
    },
    {
      number: "02",
      title: "Get Your Roadmap",
      description: "Receive a personalized learning path designed specifically for your goals and pace.",
    },
    {
      number: "03",
      title: "Start Learning",
      description: "Follow your curated resources and track your progress with real-time insights.",
    },
  ];

  return (
    <section id="how-it-works" className="relative w-full px-6 py-20 lg:px-20">
      <div className="absolute inset-0 -z-10">
        <div className="absolute right-1/4 bottom-1/4 h-[300px] w-[300px] rounded-full bg-gradient-to-l from-purple-500/20 to-transparent blur-3xl" />
      </div>

      <div className="mx-auto flex w-full max-w-full flex-col items-center">
        <Reveal className="mb-16 text-center" delay={0}>
          <h2 className="text-3xl font-bold sm:text-4xl lg:text-5xl">How It Works</h2>
          <p className="mt-4 text-lg text-muted-foreground">Three simple steps to your learning success.</p>
        </Reveal>

        <div className="w-full lg:max-w-7xl">
          <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
            {steps.map((step, index) => (
              <Reveal
                key={step.number}
                className="relative flex flex-col gap-6 rounded-2xl border border-white/10 bg-gradient-to-br from-white/10 to-white/5 p-8 backdrop-blur-sm transition hover:border-cyan-400/50 hover:bg-white/15"
                delay={index * 100}
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex h-16 w-16 items-center justify-center rounded-full border-2 border-gradient-to-r from-cyan-400 to-purple-500 bg-gradient-to-br from-cyan-500/20 to-purple-500/20 text-2xl font-bold text-cyan-400">
                    {step.number}
                  </div>
                  {index < 2 && (
                    <div className="absolute -right-4 top-8 hidden h-0.5 w-8 bg-gradient-to-r from-cyan-400 to-purple-500 md:block" />
                  )}
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-white">{step.title}</h3>
                  <p className="mt-3 text-muted-foreground">{step.description}</p>
                </div>
                <div className="flex items-center gap-2 text-sm text-cyan-400">
                  <CheckCircle2 className="h-4 w-4" />
                  <span>Proven effective</span>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;
