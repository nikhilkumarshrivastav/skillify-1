import Reveal from "@/components/ui/reveal";
import { Lightbulb, Orbit } from "lucide-react";

const highlights = [
  "Knowledge tracing tracks mastery probabilities at a concept level, illuminating strengths and gaps.",
  "Recommender architectures weigh similarity, difficulty, and retention to guide what you should study next.",
  "A fusion of graph intelligence and reinforcement signals orchestrates a personalized curriculum for every learner.",
];

const AboutSection = () => (
  <section id="about" className="relative z-10 mx-auto mt-28 max-w-6xl px-6">
    <div className="relative overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-r from-white/5 via-white/10 to-white/5 p-[1px]">
      <div className="relative rounded-[calc(1.5rem-1px)] bg-gradient-to-br from-[#1e1e2f]/90 via-[#2a2a72]/85 to-[#231942]/90 p-10">
        <span className="floating-orb -left-16 top-6 h-40 w-40 bg-cyan-500/25" style={{ animationDelay: "1.2s" }} />
        <span className="floating-orb -bottom-16 right-4 h-48 w-48 bg-purple-500/25" style={{ animationDelay: "1.8s" }} />
        <div className="relative z-10 grid gap-10 lg:grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)]">
          <div className="space-y-6">
            <Reveal className="flex items-center gap-3 text-xs uppercase tracking-[0.35em] text-white/60">
              <Orbit className="h-4 w-4 text-accent" />
              About The Project
            </Reveal>
            <Reveal as="h2" className="text-3xl font-semibold leading-snug text-white">
              AI-Based Recommendation of Study Materials using Knowledge Tracing and Recommender Architectures.
            </Reveal>
            <Reveal as="p" className="text-sm leading-relaxed text-white/70" delay={120}>
              StudyMind AI understands your cognitive journey, modeling how each concept unfolds over time. By blending the precision of knowledge tracing with adaptive recommender systems, every learner receives a tailored roadmap that evolves with every interaction.
            </Reveal>
            <div className="grid gap-4">
              {highlights.map((highlight, index) => (
                <Reveal
                  key={highlight}
                  delay={180 + index * 120}
                  className="flex gap-3 rounded-2xl border border-white/10 bg-white/5 p-4 text-sm text-white/70"
                >
                  <span className="mt-1 inline-flex h-2 w-2 flex-none rounded-full bg-accent" />
                  {highlight}
                </Reveal>
              ))}
            </div>
          </div>
          <Reveal delay={220} className="flex flex-col justify-between gap-6 rounded-2xl border border-white/10 bg-white/5 p-6 text-sm text-white/70">
            <div className="flex items-center gap-3 text-xs uppercase tracking-[0.35em] text-white/40">
              <Lightbulb className="h-4 w-4 text-accent" />
              How It Works
            </div>
            <p>
              1. Collect interaction data from quizzes, notes, and code labs. <br />
              2. Update concept mastery probabilities with Bayesian and deep tracing techniques. <br />
              3. Rank resources with hybrid recommenders balancing challenge, novelty, and retention. <br />
              4. Deliver the optimal next resource, keeping you in the flow state of learning.
            </p>
            <div className="rounded-2xl border border-accent/30 bg-accent/10 p-5 text-xs uppercase tracking-[0.3em] text-accent">
              Always adaptive. Always intentional. Always centered around your growth.
            </div>
          </Reveal>
        </div>
      </div>
    </div>
  </section>
);

export default AboutSection;
