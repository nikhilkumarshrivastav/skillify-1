import Reveal from "@/components/ui/reveal";
import { BadgeCheck, Clock, Edit3, History, Target } from "lucide-react";

const achievements = [
  {
    title: "Learning Streak",
    detail: "21 days",
    icon: Clock,
  },
  {
    title: "Concepts Mastered",
    detail: "58 of 72",
    icon: Target,
  },
  {
    title: "Badges Collected",
    detail: "12",
    icon: BadgeCheck,
  },
];

const ProfileSection = () => {
  const completionRate = 65;

  return (
    <section id="profile" className="relative z-10 mx-auto mt-28 max-w-6xl px-6">
      <div className="mb-12 flex flex-col gap-4 text-center">
        <Reveal className="section-heading mx-auto">Learner Profile</Reveal>
        <Reveal as="p" className="mx-auto max-w-2xl text-sm text-white/65" delay={100}>
          A snapshot of progress, achievements, and next objectives. Every metric is dynamically linked to your AI-generated learning trail.
        </Reveal>
      </div>
      <Reveal className="glass-card grid gap-10 p-10 lg:grid-cols-[minmax(0,1.2fr)_minmax(0,1fr)]" delay={120}>
        <div className="flex flex-col gap-8">
          <div className="flex flex-wrap items-center gap-6">
            <div className="relative h-20 w-20 rounded-3xl border border-white/10 bg-gradient-to-br from-cyan-400/35 via-purple-500/25 to-cyan-400/15 p-[1px] shadow-glow">
              <div className="flex h-full w-full items-center justify-center rounded-[calc(1.5rem-2px)] bg-background/90 text-3xl font-semibold text-white">SK</div>
            </div>
            <div>
              <h3 className="text-xl font-semibold text-white">Sofia Kane</h3>
              <p className="text-xs uppercase tracking-[0.3em] text-white/50">Front-end Explorer</p>
            </div>
            <span className="ml-auto rounded-full border border-white/10 bg-white/5 px-4 py-1 text-[0.65rem] uppercase tracking-[0.35em] text-accent">
              Platinum Tier
            </span>
          </div>
          <p className="max-w-xl text-sm leading-relaxed text-white/70">
            Sofia’s study path adapts every 12 hours using attention-weighted mastery scores. Each milestone reflects concept proficiency, energy level, and optimal focus windows derived from StudyMind’s knowledge tracing engine.
          </p>
          <div className="grid gap-4 sm:grid-cols-3">
            {achievements.map(({ title, detail, icon: Icon }) => (
              <div key={title} className="rounded-2xl border border-white/10 bg-white/5 p-4 text-sm text-white/70">
                <div className="mb-2 flex items-center gap-2 text-xs uppercase tracking-[0.3em] text-white/40">
                  <Icon className="h-4 w-4 text-accent" />
                  {title}
                </div>
                <span className="text-lg font-semibold text-white">{detail}</span>
              </div>
            ))}
          </div>
          <div className="flex flex-wrap items-center gap-4">
            <button
              type="button"
              className="btn-glow inline-flex items-center gap-2 px-5 py-2 text-xs font-semibold uppercase tracking-[0.3em]"
            >
              <Edit3 className="h-4 w-4" />
              Edit Profile
            </button>
            <button
              type="button"
              className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/10 px-5 py-2 text-xs font-semibold uppercase tracking-[0.3em] text-white/70 transition hover:-translate-y-1 hover:border-accent/40 hover:text-accent"
            >
              <History className="h-4 w-4" />
              View History
            </button>
          </div>
        </div>
        <div className="flex flex-col items-center justify-center gap-8">
          <div className="relative flex h-52 w-52 items-center justify-center">
            <div
              className="absolute inset-0 rounded-full border border-white/10"
              style={{
                background: `conic-gradient(rgba(0, 255, 255, 0.85) 0deg, rgba(127, 0, 255, 0.85) ${completionRate * 3.6}deg, rgba(255, 255, 255, 0.08) ${completionRate * 3.6}deg)` as string,
              }}
            />
            <div className="relative flex h-40 w-40 items-center justify-center rounded-full bg-background/95 text-center shadow-lg shadow-cyan-500/10">
              <span className="text-4xl font-semibold text-accent">{completionRate}%</span>
            </div>
          </div>
          <div className="text-center text-sm text-white/65">
            Completion to next milestone. Progress pulses every time a concept mastery probability exceeds threshold.
          </div>
          <div className="w-full space-y-3 rounded-2xl border border-white/10 bg-white/5 p-6 text-xs uppercase tracking-[0.3em] text-white/45">
            <div className="flex items-center justify-between text-white/60">
              <span>Study Energy</span>
              <span className="text-accent">High</span>
            </div>
            <div className="flex items-center justify-between">
              <span>Focus Window</span>
              <span className="text-accent">6pm - 8pm</span>
            </div>
            <div className="flex items-center justify-between">
              <span>Recommendation Cycle</span>
              <span className="text-accent">Every 12h</span>
            </div>
          </div>
        </div>
      </Reveal>
    </section>
  );
};

export default ProfileSection;
