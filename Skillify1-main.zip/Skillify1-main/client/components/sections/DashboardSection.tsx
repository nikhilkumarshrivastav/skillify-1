import Reveal from "@/components/ui/reveal";
import { Activity, BrainCircuit, CalendarClock } from "lucide-react";

const knowledgeLevels = [
  { label: "HTML Foundations", value: 92 },
  { label: "CSS Animations", value: 85 },
  { label: "JavaScript Mastery", value: 78 },
  { label: "Algorithms", value: 68 },
];

const upcomingMilestones = [
  "Revise dynamic programming cheat sheet",
  "Complete adaptive quiz on graph theory",
  "Watch the microlearning session on async patterns",
];

const DashboardSection = () => {
  const performanceScore = 82;
  const masteryTrend = [74, 76, 79, 81, 82];

  return (
    <section id="dashboard" className="relative z-10 mx-auto mt-28 max-w-6xl px-6">
      <div className="mb-12 flex flex-col gap-4 text-center">
        <Reveal className="section-heading mx-auto">Live Dashboard</Reveal>
        <Reveal as="p" className="mx-auto max-w-2xl text-sm text-white/65" delay={120}>
          A glassmorphic control center that blends performance analytics, knowledge progression, and AI-curated study plans.
        </Reveal>
      </div>
      <div className="grid gap-8 lg:grid-cols-3">
        <Reveal className="glass-card flex flex-col gap-6 p-8" delay={80}>
          <div className="flex items-center justify-between">
            <div>
              <span className="panel-highlight mb-3">Performance Overview</span>
              <h3 className="text-lg font-semibold text-white">Weekly Mastery Pulse</h3>
            </div>
            <Activity className="h-6 w-6 text-accent" />
          </div>
          <div className="relative mx-auto flex h-44 w-44 items-center justify-center rounded-full bg-white/5 shadow-inner">
            <div
              className="absolute inset-0 rounded-full"
              style={{
                background: `conic-gradient(rgba(0, 255, 255, 0.85) 0deg, rgba(127, 0, 255, 0.85) ${performanceScore * 3.6}deg, rgba(255, 255, 255, 0.08) ${performanceScore * 3.6}deg)` as string,
              }}
            />
            <div className="relative flex h-32 w-32 items-center justify-center rounded-full bg-background/90 text-center">
              <span className="text-3xl font-semibold text-white">{performanceScore}%</span>
            </div>
          </div>
          <div className="grid grid-cols-5 gap-2 text-xs uppercase tracking-[0.25em] text-white/40">
            {masteryTrend.map((value, index) => (
              <div key={index} className="flex flex-col items-center gap-2">
                <span className="text-[0.6rem]">Day {index + 1}</span>
                <span className="flex h-12 w-2 items-end rounded-full bg-white/10">
                  <span
                    className="w-2 rounded-full bg-gradient-to-b from-accent to-white/40"
                    style={{ height: `${value}%` }}
                  />
                </span>
              </div>
            ))}
          </div>
        </Reveal>
        <Reveal className="glass-card flex flex-col gap-6 p-8" delay={160}>
          <div className="flex items-center justify-between">
            <div>
              <span className="panel-highlight mb-3">Knowledge Level</span>
              <h3 className="text-lg font-semibold text-white">Skill Meter</h3>
            </div>
            <BrainCircuit className="h-6 w-6 text-accent" />
          </div>
          <div className="flex flex-col gap-4">
            {knowledgeLevels.map((skill) => (
              <div key={skill.label} className="space-y-2">
                <div className="flex items-center justify-between text-xs uppercase tracking-[0.25em] text-white/50">
                  <span>{skill.label}</span>
                  <span className="text-accent">{skill.value}%</span>
                </div>
                <div className="h-3 w-full overflow-hidden rounded-full bg-white/10">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-cyan-400 via-purple-500 to-cyan-400"
                    style={{ width: `${skill.value}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
          <p className="text-xs leading-relaxed text-white/60">
            Powered by knowledge tracing, each meter adapts in real time based on concept mastery, forgetting curves, and transfer learning coefficients.
          </p>
        </Reveal>
        <Reveal className="glass-card flex flex-col gap-6 p-8" delay={220}>
          <div className="flex items-center justify-between">
            <div>
              <span className="panel-highlight mb-3">Upcoming Recommendation</span>
              <h3 className="text-lg font-semibold text-white">Next Best Resource</h3>
            </div>
            <CalendarClock className="h-6 w-6 text-accent" />
          </div>
          <div className="space-y-4 rounded-2xl border border-white/10 bg-white/5 p-5 text-sm text-white/75">
            <h4 className="text-base font-semibold text-white">Microlearning Sprint</h4>
            <p>
              Structured for the next 14 hours of study. Includes interactive checkpoints, explanatory videos, and adaptive follow-up exercises.
            </p>
            <ul className="space-y-2 text-xs leading-relaxed text-white/60">
              {upcomingMilestones.map((milestone) => (
                <li key={milestone} className="flex items-start gap-2">
                  <span className="mt-1 inline-flex h-1.5 w-1.5 flex-none rounded-full bg-accent" />
                  {milestone}
                </li>
              ))}
            </ul>
          </div>
          <button
            type="button"
            className="btn-glow self-start px-5 py-2 text-xs font-semibold uppercase tracking-[0.3em]"
            onClick={() => {
              const section = document.getElementById("recommendations");
              section?.scrollIntoView({ behavior: "smooth" });
            }}
          >
            Review Plan
          </button>
        </Reveal>
      </div>
    </section>
  );
};

export default DashboardSection;
