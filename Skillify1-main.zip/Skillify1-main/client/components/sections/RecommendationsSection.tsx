import Reveal from "@/components/ui/reveal";
import { BookOpen, FileSpreadsheet, Layers, PlayCircle, Sparkles } from "lucide-react";
import { useMemo, useState, type ComponentType } from "react";

type RecommendationType = "Videos" | "Exercises" | "Notes" | "Articles";

type Recommendation = {
  id: string;
  title: string;
  description: string;
  type: RecommendationType;
  duration: string;
};

const FILTERS: Array<"All" | RecommendationType> = [
  "All",
  "Videos",
  "Exercises",
  "Notes",
  "Articles",
];

const RECOMMENDATIONS: Recommendation[] = [
  {
    id: "rec-1",
    title: "Neural Pathways in Knowledge Tracing",
    description: "Explore how recurrent neural networks follow your mastery signatures to recommend the next concept.",
    type: "Videos",
    duration: "12 min",
  },
  {
    id: "rec-2",
    title: "Adaptive Quiz: Graph Traversal",
    description: "Challenge yourself with branching scenarios that adjust difficulty based on your responses in real time.",
    type: "Exercises",
    duration: "15 min",
  },
  {
    id: "rec-3",
    title: "Concept Notes: Bayesian Knowledge Tracing",
    description: "Concise knowledge cards summarizing the latent mastery probabilities and how they shift with practice.",
    type: "Notes",
    duration: "8 min",
  },
  {
    id: "rec-4",
    title: "Microcast: Reinforcement Signals",
    description: "Listen to a guided audio breakdown on leveraging reward signals to prioritize study materials.",
    type: "Videos",
    duration: "9 min",
  },
  {
    id: "rec-5",
    title: "Hands-on Lab: Dynamic Programming",
    description: "A structured coding lab that adapts case studies according to your previous submissions.",
    type: "Exercises",
    duration: "25 min",
  },
  {
    id: "rec-6",
    title: "Knowledge Brief: Attention Mechanisms",
    description: "Discover how attention scores identify the highest-impact resource at each stage of your learning journey.",
    type: "Articles",
    duration: "6 min",
  },
  {
    id: "rec-7",
    title: "Notebook: Error Analysis",
    description: "Dive deeper into misconceptions surfaced by tracing to solidify long-term retention.",
    type: "Notes",
    duration: "10 min",
  },
  {
    id: "rec-8",
    title: "Live Session: Mentor Sync",
    description: "Schedule a mentor-led walkthrough focused on the next best resource your planner highlighted.",
    type: "Articles",
    duration: "30 min",
  },
];

const iconMap: Record<RecommendationType, ComponentType<{ className?: string }>> = {
  Videos: PlayCircle,
  Exercises: Layers,
  Notes: FileSpreadsheet,
  Articles: BookOpen,
};

const RecommendationsSection = () => {
  const [activeFilter, setActiveFilter] = useState<(typeof FILTERS)[number]>("All");

  const filteredRecommendations = useMemo(() => {
    if (activeFilter === "All") {
      return RECOMMENDATIONS;
    }
    return RECOMMENDATIONS.filter((item) => item.type === activeFilter);
  }, [activeFilter]);

  return (
    <section id="recommendations" className="relative z-10 mx-auto mt-28 max-w-6xl px-6">
      <div className="mb-12 flex flex-col gap-4 text-center">
        <Reveal className="section-heading mx-auto">AI Recommendations</Reveal>
        <Reveal as="p" className="mx-auto max-w-2xl text-sm text-white/65" delay={100}>
          Filter adaptive study resources by experience type. Every card is generated from your knowledge tracing signature.
        </Reveal>
      </div>
      <div className="mb-10 flex flex-wrap justify-center gap-3">
        {FILTERS.map((filter) => (
          <button
            key={filter}
            type="button"
            onClick={() => setActiveFilter(filter)}
            className={`chip-filter ${activeFilter === filter ? "is-active" : ""}`}
          >
            {filter}
          </button>
        ))}
      </div>
      <div className="grid gap-8 md:grid-cols-2 xl:grid-cols-3">
        {filteredRecommendations.map((item, index) => {
          const Icon = iconMap[item.type];
          return (
            <Reveal key={item.id} delay={index * 90} className="recommendation-card p-7">
              <div className="flex items-start justify-between">
                <div className="flex flex-col gap-2">
                  <span className="text-[0.65rem] uppercase tracking-[0.35em] text-white/50">{item.type}</span>
                  <h3 className="text-lg font-semibold text-white">{item.title}</h3>
                </div>
                <span className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-white/5 text-accent">
                  <Icon className="h-5 w-5" />
                </span>
              </div>
              <p className="mt-4 text-sm leading-relaxed text-white/70">{item.description}</p>
              <div className="mt-6 flex items-center justify-between text-xs uppercase tracking-[0.3em] text-white/40">
                <span className="inline-flex items-center gap-2 text-white/60">
                  <Sparkles className="h-4 w-4 text-accent" />
                  {item.duration}
                </span>
                <button
                  type="button"
                  className="btn-glow px-4 py-2 text-[0.65rem] font-semibold uppercase tracking-[0.35em]"
                >
                  {item.type === "Exercises" ? "Start" : "Open"}
                </button>
              </div>
            </Reveal>
          );
        })}
      </div>
    </section>
  );
};

export default RecommendationsSection;
