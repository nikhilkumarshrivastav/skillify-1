import Reveal from "@/components/ui/reveal";
import { ArrowRight, Sparkles } from "lucide-react";

const heroStats = [
  { label: "Adaptive Sessions", value: "128", suffix: "+" },
  { label: "Mastery Score", value: "87", suffix: "%" },
  { label: "AI Confidence", value: "92", suffix: "%" },
];

const HeroSection = () => {
  const handleCtaClick = () => {
    const section = document.getElementById("dashboard");
    section?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section id="home" className="relative z-10 mx-auto mt-40 max-w-6xl px-6">
      <div className="hero-ambient relative overflow-hidden px-6 py-16 sm:px-12 sm:py-20 lg:px-16 lg:py-24">
        <span className="floating-orb left-8 top-6 h-48 w-48 bg-cyan-500/40" style={{ animationDelay: "0.8s" }} />
        <span className="floating-orb bottom-12 right-10 h-56 w-56 bg-purple-500/40" style={{ animationDelay: "1.4s" }} />
        <div className="relative z-10 flex flex-col gap-10">
          <Reveal className="panel-highlight max-w-max">
            <Sparkles className="h-4 w-4 text-accent" />
            AI-Based Recommendation of Study Materials
          </Reveal>
          <div className="max-w-3xl space-y-6">
            <Reveal as="h1" className="text-4xl font-semibold leading-tight text-white sm:text-5xl lg:text-[3.5rem]">
              Personalized Learning Powered by AI
            </Reveal>
            <Reveal as="p" className="text-base leading-relaxed text-white/70 sm:text-lg" delay={100}>
              Smart recommendations tailored to your learning journey. StudyMind AI blends knowledge tracing with advanced recommender architectures to surface the next best resource—precisely when you need it.
            </Reveal>
            <Reveal delay={180} className="flex flex-wrap items-center gap-4">
              <button
                type="button"
                onClick={handleCtaClick}
                className="btn-glow animate-pulse-glow px-6 py-3 text-sm font-semibold uppercase tracking-[0.3em]"
              >
                Get Started
              </button>
              <a
                href="#recommendations"
                className="inline-flex items-center gap-2 text-sm font-semibold uppercase tracking-[0.3em] text-accent hover:text-white"
              >
                Explore Recommendations
                <ArrowRight className="h-4 w-4" />
              </a>
            </Reveal>
          </div>
          <div className="grid gap-6 sm:grid-cols-3">
            {heroStats.map((stat, index) => (
              <Reveal key={stat.label} delay={220 + index * 120} className="glass-card relative min-h-[8.5rem] p-6">
                <span className="text-xs uppercase tracking-[0.3em] text-white/50">{stat.label}</span>
                <div className="mt-3 flex items-end gap-1 text-3xl font-semibold text-white">
                  <span>{stat.value}</span>
                  <span className="text-lg text-accent">{stat.suffix}</span>
                </div>
                <p className="mt-3 text-xs leading-relaxed text-white/60">
                  Forecasted in real time using mastery prediction and attention-weighted signals.
                </p>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
