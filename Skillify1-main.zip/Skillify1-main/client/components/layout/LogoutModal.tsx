import { AlertCircle } from "lucide-react";

export default function LogoutModal({
  onConfirm,
  onCancel,
}: {
  onConfirm: () => void;
  onCancel: () => void;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center px-4 backdrop-blur-sm">
      <div className="animate-fade-in-up rounded-2xl border border-white/10 bg-gradient-to-br from-white/10 to-white/5 p-8 backdrop-blur-sm max-w-sm shadow-2xl">
        <div className="flex items-center gap-4 mb-6">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-red-500/20 text-red-400">
            <AlertCircle className="h-6 w-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white">Confirm Logout</h2>
            <p className="text-sm text-muted-foreground">Are you sure you want to log out?</p>
          </div>
        </div>

        <p className="mb-6 text-muted-foreground">
          You'll need to sign in again to access your dashboard and learning progress.
        </p>

        <div className="flex gap-4">
          <button
            onClick={onCancel}
            className="flex-1 rounded-lg border border-white/10 bg-white/5 px-4 py-3 font-medium text-foreground transition hover:border-white/30 hover:bg-white/10"
          >
            Cancel
          </button>
          <button
            onClick={onConfirm}
            className="flex-1 rounded-lg bg-red-500/30 px-4 py-3 font-medium text-red-400 transition hover:bg-red-500/50 border border-red-500/30 hover:border-red-500/60"
          >
            Logout
          </button>
        </div>
      </div>
    </div>
  );
}
