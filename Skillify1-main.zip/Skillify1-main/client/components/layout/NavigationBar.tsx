import ThemeToggle from "@/components/ui/theme-toggle";
import { cn } from "@/lib/utils";
import { Menu, X } from "lucide-react";
import { useEffect, useMemo, useState, type MouseEvent } from "react";

type NavItem = {
  id: string;
  label: string;
};

const NAV_ITEMS: NavItem[] = [
  { id: "home", label: "Home" },
  { id: "dashboard", label: "Dashboard" },
  { id: "recommendations", label: "Recommendations" },
  { id: "profile", label: "Profile" },
  { id: "about", label: "About" },
];

const NavigationBar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState<string>(NAV_ITEMS[0]?.id ?? "home");

  const sectionIds = useMemo(() => NAV_ITEMS.map((item) => item.id), []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];

        if (visible?.target?.id) {
          setActiveSection(visible.target.id);
        }
      },
      { threshold: 0.4 }
    );

    sectionIds.forEach((id) => {
      const element = document.getElementById(id);
      if (element) {
        observer.observe(element);
      }
    });

    return () => {
      observer.disconnect();
    };
  }, [sectionIds]);

  useEffect(() => {
    if (!isMenuOpen) {
      return;
    }

    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setIsMenuOpen(false);
      }
    };

    window.addEventListener("keydown", handleEscape);
    return () => window.removeEventListener("keydown", handleEscape);
  }, [isMenuOpen]);

  const handleNavigate = (event: MouseEvent<HTMLAnchorElement>, id: string) => {
    event.preventDefault();
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
      setActiveSection(id);
    }
    setIsMenuOpen(false);
  };

  const handleCta = () => {
    const element = document.getElementById("recommendations");
    element?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <header className="fixed inset-x-0 top-4 z-40 flex justify-center px-4">
      <nav className="glassy-nav relative flex w-[min(1100px,100%)] items-center justify-between rounded-2xl px-5 py-4 shadow-glass-lg">
        <div className="flex items-center gap-10">
          <a
            href="#home"
            onClick={(event) => handleNavigate(event, "home")}
            className="relative flex items-center gap-2 text-base font-semibold tracking-[0.35em] text-foreground"
          >
            <span className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-white/10 text-lg font-bold text-accent shadow-glow">
              AI
            </span>
            <span className="hidden flex-col leading-tight sm:flex">
              <span className="text-xs font-medium uppercase tracking-[0.5em] text-white/60">StudyMind</span>
              <span className="text-sm font-semibold uppercase tracking-[0.4em] text-white">AI</span>
            </span>
          </a>
          <div className="hidden items-center gap-2 lg:flex">
            {NAV_ITEMS.map((item) => (
              <a
                key={item.id}
                href={`#${item.id}`}
                onClick={(event) => handleNavigate(event, item.id)}
                className={cn("underline-link", {
                  active: activeSection === item.id,
                })}
              >
                {item.label}
              </a>
            ))}
          </div>
        </div>
        <div className="flex items-center gap-4">
          <button
            type="button"
            onClick={handleCta}
            className="btn-glow hidden px-5 py-2 text-xs font-semibold uppercase tracking-[0.3em] shadow-glow sm:block"
          >
            Get Started
          </button>
          <ThemeToggle />
          <button
            type="button"
            onClick={() => setIsMenuOpen((prev) => !prev)}
            className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-white/15 bg-white/5 text-foreground/80 backdrop-blur-md transition hover:-translate-y-0.5 hover:border-accent/60 hover:text-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/70 lg:hidden"
            aria-expanded={isMenuOpen}
            aria-label="Toggle navigation menu"
          >
            {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </nav>
      {isMenuOpen && (
        <div className="glassy-nav absolute top-[72px] z-40 w-full max-w-[min(1100px,calc(100%-2rem))] rounded-2xl px-5 py-4 lg:hidden">
          <div className="flex flex-col gap-2">
            {NAV_ITEMS.map((item) => (
              <a
                key={item.id}
                href={`#${item.id}`}
                onClick={(event) => handleNavigate(event, item.id)}
                className={cn("underline-link w-full justify-start rounded-xl border border-white/10 bg-white/5 py-3 text-sm", {
                  active: activeSection === item.id,
                })}
              >
                {item.label}
              </a>
            ))}
            <button
              type="button"
              onClick={() => {
                setIsMenuOpen(false);
                handleCta();
              }}
              className="btn-glow mt-1 w-full rounded-full px-5 py-3 text-sm font-semibold uppercase tracking-[0.3em]"
            >
              Get Started
            </button>
          </div>
        </div>
      )}
    </header>
  );
};

export default NavigationBar;
