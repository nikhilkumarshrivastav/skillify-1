import { Github, Linkedin, Mail } from "lucide-react";
import Reveal from "@/components/ui/reveal";

const socialLinks = [
  {
    id: "linkedin",
    label: "LinkedIn",
    href: "https://www.linkedin.com",
    icon: Linkedin,
  },
  {
    id: "github",
    label: "GitHub",
    href: "https://github.com",
    icon: Github,
  },
  {
    id: "mail",
    label: "Email",
    href: "mailto:hello@studymind.ai",
    icon: Mail,
  },
];

const SiteFooter = () => (
  <footer className="relative z-10 mt-24 border-t border-white/10 bg-gradient-to-b from-transparent via-white/5 to-white/10/40">
    <div className="gradient-divider" />
    <div className="mx-auto flex max-w-6xl flex-col gap-8 px-6 py-12 text-sm text-white/70 md:flex-row md:items-center md:justify-between">
      <Reveal className="flex flex-col gap-2 text-xs uppercase tracking-[0.35em]">
        <span className="text-white/40">AI-Based Recommendation</span>
        <span className="text-white">StudyMind AI Platform</span>
      </Reveal>
      <Reveal className="flex items-center gap-4" delay={120}>
        {socialLinks.map(({ id, label, href, icon: Icon }) => (
          <a
            key={id}
            href={href}
            target="_blank"
            rel="noreferrer"
            className="inline-flex h-11 w-11 items-center justify-center rounded-full border border-white/15 bg-white/10 text-white/70 transition hover:-translate-y-1 hover:border-accent/40 hover:text-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/60"
            aria-label={label}
          >
            <Icon className="h-5 w-5" />
          </a>
        ))}
      </Reveal>
    </div>
    <div className="mx-auto w-full max-w-6xl px-6 pb-10 text-xs uppercase tracking-[0.35em] text-white/40">
      © {new Date().getFullYear()} StudyMind AI. All rights reserved.
    </div>
  </footer>
);

export default SiteFooter;
