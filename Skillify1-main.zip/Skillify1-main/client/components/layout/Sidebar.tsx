import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { LogOut, Menu, X, Home, Brain, BookOpen, Map, BarChart3, User } from "lucide-react";
import { cn } from "@/lib/utils";
import SkillifyLogo from "@/components/ui/skillify-logo";

const Sidebar = ({ onLogout }: { onLogout: () => void }) => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  const navItems = [
    { href: "/dashboard", label: "Dashboard", icon: Home },
    { href: "/skill-analyzer", label: "Skill Analyzer", icon: Brain },
    { href: "/recommendations", label: "Recommendations", icon: BookOpen },
    { href: "/roadmap", label: "Roadmap", icon: Map },
    { href: "/profile", label: "Profile", icon: User },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <>
      {/* Desktop Sidebar */}
      <aside className="hidden w-64 flex-col border-r border-white/10 bg-gradient-to-b from-white/10 via-white/5 to-transparent backdrop-blur-sm lg:flex">
        <div className="flex items-center gap-3 border-b border-white/10 px-6 py-4">
          <div className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-white/10 shadow-glow">
            <SkillifyLogo className="h-8 w-8" />
          </div>
          <span className="text-lg font-bold uppercase tracking-wide text-white">Skillify</span>
        </div>

        <nav className="flex-1 space-y-2 px-4 py-6">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = isActive(item.href);
            return (
              <Link
                key={item.href}
                to={item.href}
                className={cn(
                  "flex items-center gap-3 rounded-lg px-4 py-3 text-sm font-medium transition duration-200",
                  active
                    ? "bg-gradient-to-r from-cyan-500/30 to-purple-500/20 text-white border border-cyan-400/30"
                    : "text-muted-foreground hover:text-foreground hover:bg-white/5"
                )}
              >
                <Icon className="h-5 w-5" />
                <span>{item.label}</span>
              </Link>
            );
          })}
        </nav>

        <div className="border-t border-white/10 px-4 py-6">
          <button
            onClick={onLogout}
            className="flex w-full items-center gap-3 rounded-lg px-4 py-3 text-sm font-medium text-red-400 transition hover:bg-red-500/10 hover:text-red-300"
          >
            <LogOut className="h-5 w-5" />
            <span>Logout</span>
          </button>
        </div>
      </aside>

      {/* Mobile Header */}
      <header className="sticky top-0 z-30 flex lg:hidden items-center justify-between border-b border-white/10 bg-gradient-to-r from-white/10 to-transparent px-4 py-3 backdrop-blur-md">
        <Link to="/dashboard" className="flex items-center gap-2">
          <div className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-white/10 shadow-glow">
            <SkillifyLogo className="h-8 w-8" />
          </div>
          <span className="text-lg font-bold uppercase tracking-wide text-white">Skillify</span>
        </Link>

        <button
          onClick={() => setIsOpen(!isOpen)}
          className="inline-flex h-10 w-10 items-center justify-center rounded-lg border border-white/15 bg-white/5 text-foreground/80 transition hover:bg-white/10"
          aria-label="Toggle menu"
        >
          {isOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </header>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="lg:hidden absolute top-16 left-0 right-0 z-20 border-b border-white/10 bg-gradient-to-b from-white/10 to-white/5 backdrop-blur-md">
          <nav className="space-y-2 p-4">
            {navItems.map((item) => {
              const Icon = item.icon;
              const active = isActive(item.href);
              return (
                <Link
                  key={item.href}
                  to={item.href}
                  onClick={() => setIsOpen(false)}
                  className={cn(
                    "flex items-center gap-3 rounded-lg px-4 py-3 text-sm font-medium transition",
                    active
                      ? "bg-gradient-to-r from-cyan-500/30 to-purple-500/20 text-white"
                      : "text-muted-foreground hover:text-foreground hover:bg-white/5"
                  )}
                >
                  <Icon className="h-5 w-5" />
                  <span>{item.label}</span>
                </Link>
              );
            })}
            <button
              onClick={onLogout}
              className="flex w-full items-center gap-3 rounded-lg px-4 py-3 text-sm font-medium text-red-400 transition hover:bg-red-500/10"
            >
              <LogOut className="h-5 w-5" />
              <span>Logout</span>
            </button>
          </nav>
        </div>
      )}
    </>
  );
};

export default Sidebar;
