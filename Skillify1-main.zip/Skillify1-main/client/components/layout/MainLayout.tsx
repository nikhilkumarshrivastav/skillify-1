import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Sidebar from "./Sidebar";
import LogoutModal from "./LogoutModal";

export default function MainLayout({ children }: { children: React.ReactNode }) {
  const [showLogoutModal, setShowLogoutModal] = useState(false);
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("auth_token");
    localStorage.removeItem("user_email");
    localStorage.removeItem("user_name");
    navigate("/");
  };

  return (
    <div className="relative flex min-h-screen flex-col overflow-hidden lg:flex-row">
      <div className="pointer-events-none fixed inset-0 -z-10 opacity-40 [background-image:radial-gradient(circle_at_top_left,rgba(0,255,255,0.12),transparent_45%),radial-gradient(circle_at_bottom_right,rgba(127,0,255,0.12),transparent_45%)]" />

      <Sidebar onLogout={() => setShowLogoutModal(true)} />

      <main className="flex-1 overflow-y-auto">
        <div className="flex flex-col">
          {children}
        </div>
      </main>

      {showLogoutModal && (
        <LogoutModal onConfirm={handleLogout} onCancel={() => setShowLogoutModal(false)} />
      )}
    </div>
  );
}
