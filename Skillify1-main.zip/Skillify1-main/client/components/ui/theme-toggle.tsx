// Theme toggle disabled — always dark mode
export default function ThemeToggle() {
  return null; // This hides the toggle button completely
}
