import { cn } from "@/lib/utils";
import type { CSSProperties, HTMLAttributes, ReactNode } from "react";
import { useEffect, useRef } from "react";

type RevealProps = {
  as?: keyof HTMLElementTagNameMap;
  delay?: number;
  className?: string;
  children?: ReactNode;
  style?: CSSProperties;
  [key: string]: unknown;
};

const Reveal = ({
  as = "div",
  delay = 0,
  className,
  children,
  style,
  ...rest
}: RevealProps) => {
  const elementRef = useRef<HTMLElement | null>(null);

  useEffect(() => {
    const element = elementRef.current;
    if (!element) {
      return undefined;
    }

    element.style.setProperty("--reveal-delay", `${delay}ms`);

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("fade-in-visible");
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.2 }
    );

    observer.observe(element);

    return () => {
      observer.disconnect();
    };
  }, [delay]);

  const Component = as as any;

  return (
    <Component
      ref={elementRef}
      className={cn("fade-in-element", className)}
      style={{
        ...(style as CSSProperties),
        ["--reveal-delay" as string]: `${delay}ms`,
      }}
      {...rest}
    >
      {children}
    </Component>
  );
};

export default Reveal;
