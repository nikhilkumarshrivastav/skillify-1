const SkillifyLogo = ({ className = "h-8 w-8" }) => {
  return (
    <svg
      viewBox="0 0 100 100"
      className={className}
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* Outer circle background */}
      <circle cx="50" cy="50" r="48" fill="url(#gradBg)" />

      {/* S Shape Path */}
      <g strokeLinecap="round" strokeLinejoin="round" fill="none">
        {/* Top curve */}
        <path
          d="M 25 30 Q 25 20 40 20 Q 55 20 60 28 Q 62 32 58 35 Q 45 45 30 50"
          stroke="url(#grad1)"
          strokeWidth="7"
        />
        {/* Bottom curve */}
        <path
          d="M 70 50 Q 55 55 42 65 Q 38 68 42 72 Q 45 80 60 80 Q 75 80 75 70"
          stroke="url(#grad2)"
          strokeWidth="7"
        />
      </g>

      <defs>
        <linearGradient id="gradBg" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#00ffff" stopOpacity="0.3" />
          <stop offset="100%" stopColor="#7f00ff" stopOpacity="0.25" />
        </linearGradient>
        <linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#00ffff" />
          <stop offset="100%" stopColor="#00d4ff" />
        </linearGradient>
        <linearGradient id="grad2" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#7f00ff" />
          <stop offset="100%" stopColor="#00ffff" />
        </linearGradient>
      </defs>
    </svg>
  );
};

export default SkillifyLogo;
