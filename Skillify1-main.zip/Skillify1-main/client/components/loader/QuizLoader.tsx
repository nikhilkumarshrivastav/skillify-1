import { useEffect, useState } from "react";

const messages = [
  "Analyzing your background...",
  "Reviewing your experience...",
  "Processing competencies...",
  "Matching difficulty levels...",
  "Generating your personalized questions...",
  "Finalizing assessment..."
];

export default function QuizLoader({ onComplete }: { onComplete: () => void }) {
  const [progress, setProgress] = useState(0);
  const [msgIndex, setMsgIndex] = useState(0);

  useEffect(() => {
    let bar = setInterval(() => {
      setProgress((p) => (p < 100 ? p + 1 : 100));
    }, 110); // smooth slow progress (~12 seconds)

    let textChange = setInterval(() => {
      setMsgIndex((i) => (i < messages.length - 1 ? i + 1 : i));
    }, 2000);

    setTimeout(() => {
      clearInterval(bar);
      clearInterval(textChange);
      onComplete();
    }, 12000);

    return () => {
      clearInterval(bar);
      clearInterval(textChange);
    };
  }, []);

  return (
    <div className="w-full h-screen flex items-center justify-center bg-gradient-to-br from-[#0a0f1f] to-[#05070d]">
      <div className="text-center flex flex-col items-center">
        
        {/* Title */}
        <h2 className="text-2xl font-bold text-white mb-4 tracking-wide">
          {messages[msgIndex]}
        </h2>

        {/* Progress Bar */}
        <div className="w-[350px] h-3 bg-white/10 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-cyan-400 to-purple-500 transition-all duration-200"
            style={{ width: `${progress}%` }}
          ></div>
        </div>

        {/* Subtext */}
        <p className="text-gray-400 text-sm mt-4">
          Preparing your personalized quiz…
        </p>
      </div>
    </div>
  );
}
