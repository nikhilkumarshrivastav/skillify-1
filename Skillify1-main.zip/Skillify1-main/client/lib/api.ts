// client/lib/api.ts

export const BACKEND_URL = "http://127.0.0.1:8000";

export async function apiRequest(endpoint: string, method: string = "GET", body?: any) {
  const options: RequestInit = {
    method,
    headers: {
      "Content-Type": "application/json",
    },
  };

  if (body) {
    options.body = JSON.stringify(body);
  }

  const response = await fetch(`${BACKEND_URL}${endpoint}`, options);
  
  if (!response.ok) {
    const errorData = await response.json().catch(() => ({ detail: "An error occurred" }));
    throw new Error(errorData.detail || "Request failed");
  }

  return response.json();
}
