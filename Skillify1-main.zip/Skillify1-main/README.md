# Skillify

A full-stack application with a React (Vite) frontend and a Python (FastAPI) backend.

## Prerequisites

Before you start, make sure you have the following installed on your system:
- **Node.js**: (Version 18 or higher recommended) - [Download Node.js](https://nodejs.org/)
- **Python**: (Version 3.8 or higher) - [Download Python](https://www.python.org/downloads/)
- **VS Code** (or your preferred code editor)

---

## 🚀 Step 1: Frontend Setup (React/Vite)

The frontend is built using React, TypeScript, and Vite, and uses styling libraries like TailwindCSS and Radix UI.

1. **Open a terminal** and navigate to the project root directory (`Skillify`).
2. **Install all frontend dependencies** by running:
   ```powershell
   npm install
   ```
   *(If you encounter errors regarding corrupted modules, run `Remove-Item -Recurse -Force node_modules` and `npm cache clean --force` first, then run `npm install` again).*

---

## 🐍 Step 2: Backend Setup (Python/FastAPI)

The backend handles the AI question generation logic and serves API endpoints using FastAPI. 

1. **Open a NEW terminal window** in VS Code.
2. **Navigate into the server folder:**
   ```powershell
   cd server
   ```
3. **Create a Virtual Environment** (This keeps your Python packages isolated):
   ```powershell
   python -m venv venv
   ```
4. **Activate the Virtual Environment:**
   * **On Windows (PowerShell):**
     ```powershell
     .\venv\Scripts\activate
     ```
   * **On Mac/Linux:**
     ```bash
     source venv/bin/activate
     ```
   *(You should now see `(venv)` at the beginning of your terminal prompt).*
5. **Install backend dependencies:**
   ```powershell
   pip install -r requirements.txt
   ```
   *Or, if you prefer installing manually, run:*
   `pip install fastapi uvicorn pydantic python-multipart numpy scikit-learn sqlalchemy oracledb python-dotenv "passlib[bcrypt]" "python-jose[cryptography]"`

---

## ▶️ Step 3: Running the Application

To run the application locally, you will need to keep **both** your Frontend and Backend servers running at the same time in two separate terminal windows.

### 1. Start the Backend Server
In your `server` terminal (make sure your `(venv)` is still active):
```powershell
# Make sure you are inside the 'server' directory
cd server
.\venv\Scripts\Activate.ps1
uvicorn app:app --reload --port 8000
```

*The backend will start running at: `http://127.0.0.1:8000`*

### 2. Start the Frontend Server
In your main terminal (at the root `Skillify` directory):
```powershell
pnpm dev
```

*The frontend will start running at: `http://localhost:8080/`*

Now, open your browser and navigate to `http://localhost:8080/` to use Skillify!
