import sys

file_path = r'c:\Users\snikh\OneDrive\Desktop\Skillify-main\client\pages\Login.tsx'

# Read as bytes to avoid encoding issues
with open(file_path, 'rb') as f:
    content_bytes = f.read()

# Convert to string using latin-1 which is safe for all bytes
content = content_bytes.decode('latin-1')

replacement = """                <div className="flex items-center justify-between mb-2">
                  <label htmlFor="password" className="block text-sm font-medium text-foreground">
                    Password
                  </label>
                  <a href="/forgot-password" class="text-xs font-medium text-cyan-400 hover:text-cyan-300">
                    Forgot Password?
                  </a>
                </div>"""

# Case-insensitive replacement of the password label block
import re
new_content = re.sub(
    r'<label htmlFor="password" className="block text-sm font-medium\s+text-foreground mb-2">\s+Password\s+</label>',
    replacement,
    content,
    flags=re.IGNORECASE | re.DOTALL
)

if new_content == content:
    print("Warning: Content not changed via Regex. Trying literal search.")
    # Generic fallback
    if "Password" in content:
        new_content = content.replace('Password</label>', 'Password</label><a href="/forgot-password">Forgot?</a>')

# Write back
with open(file_path, 'wb') as f:
    f.write(new_content.encode('latin-1'))

print("Modified Login.tsx successfully")
