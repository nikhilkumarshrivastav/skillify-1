import sys

file_path = r'c:\Users\snikh\OneDrive\Desktop\Skillify-main\client\pages\SignUp.tsx'

new_content = r'''import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { User, Mail, Lock, Sparkles, CheckCircle, Loader2 } from "lucide-react";
import { supabase } from "@/lib/supabase";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/api";
import {
  InputOTP,
  InputOTPGroup,
  InputOTPSlot,
} from "@/components/ui/input-otp";

export default function SignUp() {
  const [step, setStep] = useState<"form" | "otp">("form");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [otp, setOtp] = useState("");
  const [otpToken, setOtpToken] = useState("");
  
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleSignupRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setIsLoading(true);

    try {
      const response = await apiRequest("/auth/signup-otp", "POST", { email });
      setOtpToken(response.token);
      setStep("otp");
      
      toast({
        title: "Verification Sent",
        description: "Please check your email for the verification code.",
      });
    } catch (err: any) {
      setError(err.message || "An error occurred. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerifyOtpAndSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setIsLoading(true);

    try {
      const { data, error: signUpError } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            name: name,
          },
        },
      });

      if (signUpError) throw signUpError;

      toast({
        title: "Account created!",
        description: "Welcome to Skillify.",
      });
      navigate("/dashboard");
      
    } catch (err: any) {
      setError(err.message || "Verification failed.");
    } finally {
      setIsLoading(false);
    }
  };

  const features = [
    { icon: Sparkles, text: "AI-Powered Skill Assessment" },
    { icon: CheckCircle, text: "Personalized Learning Paths" },
    { icon: Sparkles, text: "Real-Time Progress Tracking" },
  ];

  return (
    <div className="relative flex min-h-screen bg-background">
      <div className="pointer-events-none fixed inset-0 -z-10 opacity-40 
        [background-image:radial-gradient(circle_at_top_left,rgba(0,255,255,0.12),transparent_45%),
        radial-gradient(circle_at_bottom_right,rgba(127,0,255,0.12),transparent_45%)]" />

      <div className="hidden flex-1 flex-col items-start justify-between 
        bg-gradient-to-br from-purple-900/30 via-transparent to-cyan-900/20 p-12 lg:flex">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl 
            bg-gradient-to-br from-cyan-400 to-purple-500 shadow-lg shadow-cyan-500/20">
            <Sparkles className="h-6 w-6 text-white" />
          </div>
          <span className="text-2xl font-bold uppercase tracking-wider text-white">
            Skillify
          </span>
        </div>

        <div className="max-w-sm space-y-8 text-white">
          <div className="space-y-4">
            <h2 className="text-4xl font-bold leading-tight">
              Master Any Skill with AI
            </h2>
            <p className="text-lg text-muted-foreground">
              Get personalized learning paths tailored to your goals and progress at your pace.
            </p>
          </div>

          <div className="space-y-4">
            {features.map((feature) => {
              const Icon = feature.icon;
              return (
                <div key={feature.text} className="flex items-center gap-3">
                  <Icon className="h-6 w-6 text-cyan-400 flex-shrink-0" />
                  <span>{feature.text}</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <div className="flex flex-1 items-center justify-center p-8">
        <div className="w-full max-w-md">
          <div className="mb-10 text-center lg:text-left">
            <h1 className="text-3xl font-bold text-white">
              {step === "form" ? "Create Account" : "Verify Email"}
            </h1>
            <p className="mt-2 text-muted-foreground">
              {step === "form" ? "Join thousands of learners today." : `Enter the code sent to ${email}`}
            </p>
          </div>

          {error && (
            <div className="mb-6 rounded-lg bg-red-500/10 p-3 text-sm text-red-500 border border-red-500/20">
              {error}
            </div>
          )}

          {step === "form" ? (
            <form onSubmit={handleSignupRequest} className="space-y-4">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-foreground mb-2">
                  Full Name
                </label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
                  <input
                    id="name"
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="John Doe"
                    required
                    className="w-full rounded-lg border border-white/10 bg-white/5 py-3 pl-10 pr-4 text-white 
                      focus:border-cyan-400/50 focus:bg-white/10 focus:outline-none focus:ring-2 focus:ring-cyan-400/30"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="email" className="block text-sm font-medium text-foreground mb-2">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
                  <input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="abc@gmail.com"
                    required
                    className="w-full rounded-lg border border-white/10 bg-white/5 py-3 pl-10 pr-4 text-white 
                      focus:border-cyan-400/50 focus:bg-white/10 focus:outline-none focus:ring-2 focus:ring-cyan-400/30"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="password" tag="label" className="text-sm font-medium text-foreground mb-2 block">
                  Password
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
                  <input
                    id="password"
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    required
                    className="w-full rounded-lg border border-white/10 bg-white/5 py-3 pl-10 pr-4 text-white 
                      focus:border-cyan-400/50 focus:bg-white/10 focus:outline-none focus:ring-2 focus:ring-cyan-400/30"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full rounded-lg bg-cyan-500 py-3 font-semibold text-white transition-all 
                  hover:bg-cyan-400 disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {isLoading && <Loader2 className="h-4 w-4 animate-spin" />}
                {isLoading ? "Sending Code..." : "Sign Up"}
              </button>
            </form>
          ) : (
            <form onSubmit={handleVerifyOtpAndSignup} className="space-y-6">
              <div className="flex flex-col items-center gap-4">
                <InputOTP
                  maxLength={6}
                  value={otp}
                  onChange={(val) => setOtp(val)}
                  className="text-white"
                >
                  <InputOTPGroup>
                    <InputOTPSlot index={0} />
                    <InputOTPSlot index={1} />
                    <InputOTPSlot index={2} />
                  </InputOTPGroup>
                  <InputOTPGroup>
                    <InputOTPSlot index={3} />
                    <InputOTPSlot index={4} />
                    <InputOTPSlot index={5} />
                  </InputOTPGroup>
                </InputOTP>
              </div>

              <button
                type="submit"
                disabled={isLoading || otp.length < 6}
                className="w-full rounded-lg bg-cyan-500 py-3 font-semibold text-white transition-all 
                  hover:bg-cyan-400 disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {isLoading && <Loader2 className="h-4 w-4 animate-spin" />}
                {isLoading ? "Verifying..." : "Verify & Create Account"}
              </button>

              <button
                type="button"
                onClick={() => setStep("form")}
                className="w-full text-center text-sm text-cyan-400 hover:underline"
              >
                Change Email / Back
              </button>
            </form>
          )}

          <p className="mt-6 text-center text-sm text-muted-foreground">
            Already have an account?{" "}
            <Link to="/login" className="font-semibold text-cyan-400 hover:text-cyan-300">
              Sign in
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
'''

# Write as bytes using latin-1 or utf-8
with open(file_path, 'wb') as f:
    f.write(new_content.encode('utf-8'))

print("Updated SignUp.tsx successfully")
