import json

INPUT = "server/data/gemini-code-1777238217563.json"
OUTPUT = "server/data/clean.json"


def fix():
    with open(INPUT, "r", encoding="utf-8") as f:
        content = f.read()

    # Split multiple JSON objects
    objects = []
    buffer = ""
    brace_count = 0

    for char in content:
        buffer += char

        if char == "{":
            brace_count += 1
        elif char == "}":
            brace_count -= 1

        # when one full JSON object ends
        if brace_count == 0 and buffer.strip():
            try:
                obj = json.loads(buffer)
                objects.append(obj)
                buffer = ""
            except:
                pass  # skip broken parts

    # Wrap into domains structure
    fixed = {"domains": objects}

    with open(OUTPUT, "w", encoding="utf-8") as f:
        json.dump(fixed, f, indent=2)

    print(f"✅ Fixed {len(objects)} objects → saved to clean.json")


if __name__ == "__main__":
    fix()