import json

# INPUT FILE (your current JSON)
INPUT_FILE = "/data/gemini-code-1777238217563.json"

# OUTPUT FILE (correct structure)
OUTPUT_FILE = "server/data/skillanalyzer.json"


def normalize_name(name: str):
    return name.lower().replace(" ", "-")


def convert():
    with open(INPUT_FILE, "r", encoding="utf-8") as f:
        raw = json.load(f)

    fixed = {}

    # CASE 1: if structure has "domains"
    if "domains" in raw:
        for domain in raw["domains"]:
            dname = normalize_name(domain["name"])

            fixed[dname] = {
                "beginner": [],
                "intermediate": [],
                "experienced": []
            }

            for lvl in domain.get("levels", []):
                difficulty = lvl.get("difficulty")

                if difficulty not in fixed[dname]:
                    continue

                for q in lvl.get("questions", []):
                    fixed[dname][difficulty].append({
                        "question": q.get("question"),
                        "options": q.get("options"),
                        "answer": q.get("answer")
                    })

    # CASE 2: already correct → just copy
    else:
        fixed = raw

    # SAVE
    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        json.dump(fixed, f, indent=2)

    print("✅ JSON fixed and saved to:", OUTPUT_FILE)


if __name__ == "__main__":
    convert()