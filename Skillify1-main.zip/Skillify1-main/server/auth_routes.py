from fastapi import APIRouter, HTTPException, Body
from pydantic import BaseModel, EmailStr
from auth_utils import generate_otp, create_otp_token, verify_otp_token, send_otp_email, hash_password
import os

router = APIRouter(prefix="/auth", tags=["auth"])

class ForgotPasswordRequest(BaseModel):
    email: EmailStr

class ResetPasswordRequest(BaseModel):
    token: str
    otp: str
    email: str
    new_password: str

class SignupOTPRequest(BaseModel):
    email: EmailStr

# ---------------------------------------------------------
# FORGOT PASSWORD - SEND OTP
# ---------------------------------------------------------
@router.post("/forgot-password")
async def forgot_password(data: ForgotPasswordRequest):
    email = data.email
    
    # Generate OTP and stateless token
    otp = generate_otp()
    token = create_otp_token(email, otp, "reset_password")
    
    # Send email
    success = send_otp_email(email, otp, type="reset")
    if not success:
        raise HTTPException(status_code=500, detail="Failed to send OTP email")
    
    return {
        "message": "OTP sent to email",
        "token": token # Return token to be used in next step
    }

# ---------------------------------------------------------
# RESET PASSWORD - VERIFY OTP & UPDATE
# ---------------------------------------------------------
@router.post("/reset-password")
async def reset_password(data: ResetPasswordRequest):
    # Verify stateless OTP
    is_valid, message = verify_otp_token(data.token, data.otp, data.email, "reset_password")
    if not is_valid:
        raise HTTPException(status_code=400, detail=message)
    
    # Hash password
    hashed_pwd = hash_password(data.new_password)
    
    # TODO: Update user password in DB
    # Since we are using Supabase, this would normally be done via Supabase Admin SDK
    # or a direct PostgreSQL update if we had the connection string.
    print(f"DATABASE UPDATE: Set password for {data.email} to {hashed_pwd}")
    
    return {"message": "Password updated successfully"}

# ---------------------------------------------------------
# SIGNUP OTP - SEND OTP
# ---------------------------------------------------------
@router.post("/signup-otp")
async def signup_otp(data: SignupOTPRequest):
    email = data.email
    
    # Generate OTP and stateless token
    otp = generate_otp()
    token = create_otp_token(email, otp, "signup_verification")
    
    # Send email
    success = send_otp_email(email, otp, type="signup")
    if not success:
        raise HTTPException(status_code=500, detail="Failed to send verification email")
    
    return {
        "message": "Verification code sent to email",
        "token": token
    }
