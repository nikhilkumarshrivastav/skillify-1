import os
import random
import string
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime, timedelta
from jose import jwt, JWTError
from passlib.context import CryptContext
from dotenv import load_dotenv

load_dotenv()

# JWT Config
JWT_SECRET = os.getenv("JWT_SECRET", "default_secret")
JWT_ALGORITHM = os.getenv("JWT_ALGORITHM", "HS256")

# Password Hashing
pwd_context = CryptContext(schemes=["pbkdf2_sha256"], deprecated="auto")

# SMTP Config
SMTP_SERVER = os.getenv("SMTP_SERVER", "smtp.gmail.com")
SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
EMAIL_USER = os.getenv("EMAIL_USER")
EMAIL_PASSWORD = os.getenv("EMAIL_PASSWORD")

def generate_otp(length=6):
    return ''.join(random.choices(string.digits, k=length))

def hash_password(password: str):
    return pwd_context.hash(password)

def verify_password(plain_password: str, hashed_password: str):
    return pwd_context.verify(plain_password, hashed_password)

def create_otp_token(email: str, otp: str, purpose: str):
    expire = datetime.utcnow() + timedelta(minutes=10)
    to_encode = {
        "email": email,
        "otp": otp,
        "purpose": purpose,
        "exp": expire
    }
    return jwt.encode(to_encode, JWT_SECRET, algorithm=JWT_ALGORITHM)

def verify_otp_token(token: str, otp: str, email: str, purpose: str):
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        if payload.get("email") != email:
            return False, "Email mismatch"
        if str(payload.get("otp")) != str(otp):
            return False, "Invalid OTP"
        if payload.get("purpose") != purpose:
            return False, "Invalid token purpose"
        return True, "Valid"
    except jwt.ExpiredSignatureError:
        return False, "OTP has expired"
    except JWTError:
        return False, "Invalid token"

def send_email(to_email: str, subject: str, body: str):
    if not EMAIL_USER or not EMAIL_PASSWORD:
        print(f"SMTP Credentials missing. OTP for {to_email}: {body}")
        return True # Mock success in dev if missing

    try:
        msg = MIMEMultipart()
        msg['From'] = f"Skillify <{EMAIL_USER}>"
        msg['To'] = to_email
        msg['Subject'] = subject

        msg.attach(MIMEText(body, 'html'))

        server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
        server.starttls()
        server.login(EMAIL_USER, EMAIL_PASSWORD)
        server.send_message(msg)
        server.quit()
        return True
    except Exception as e:
        print(f"Error sending email: {e}")
        return False

def send_otp_email(to_email: str, otp: str, type="reset"):
    subject = "Your Skillify Verification Code"
    if type == "reset":
        body = f"""
        <html>
            <body style="font-family: sans-serif;">
                <h2 style="color: #06b6d4;">Password Reset Request</h2>
                <p>Hello,</p>
                <p>You requested to reset your password. Use the following OTP to continue:</p>
                <div style="font-size: 24px; font-weight: bold; background: #f3f4f6; padding: 10px; display: inline-block; border-radius: 5px; color: #1e293b;">
                    {otp}
                </div>
                <p>This code will expire in 10 minutes.</p>
                <p>If you didn't request this, please ignore this email.</p>
                <hr/>
                <p style="font-size: 12px; color: #64748b;">Powered by Skillify AI</p>
            </body>
        </html>
        """
    else:
        body = f"""
        <html>
            <body style="font-family: sans-serif;">
                <h2 style="color: #06b6d4;">Welcome to Skillify!</h2>
                <p>Verify your email to create your account:</p>
                <div style="font-size: 24px; font-weight: bold; background: #f3f4f6; padding: 10px; display: inline-block; border-radius: 5px; color: #1e293b;">
                    {otp}
                </div>
                <p>This code will expire in 10 minutes.</p>
                <hr/>
                <p style="font-size: 12px; color: #64748b;">Powered by Skillify AI</p>
            </body>
        </html>
        """
    return send_email(to_email, subject, body)
