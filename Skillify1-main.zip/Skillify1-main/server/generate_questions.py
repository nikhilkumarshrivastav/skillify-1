import json
import random

# =========================
# LOAD JSON
# =========================
def load_data():
    with open("data/NIKHIL.json", "r", encoding="utf-8") as f:
        return json.load(f)


# =========================
# ADD IDS
# =========================
def add_ids(questions, start_id=1):
    for i, q in enumerate(questions):
        q["id"] = start_id + i
    return questions


# =========================
# WEIGHT LOGIC
# =========================
def weighted_selection(beg, inter, adv, exp, past):

    if exp == "beginner" or past == "none":
        weights = (6, 3, 1)
    elif exp == "intermediate" or past == "some":
        weights = (3, 4, 3)
    else:
        weights = (0, 5, 5)

    b, i, a = weights

    selected = []
    selected += random.sample(beg, min(b, len(beg)))
    selected += random.sample(inter, min(i, len(inter)))
    selected += random.sample(adv, min(a, len(adv)))

    random.shuffle(selected)

    return selected[:10]


# =========================
# MAIN FUNCTION (FIXED)
# =========================
def get_questions(domain: str, exp: str, past: str, backend: str = None):
    data = load_data()

    # normalize
    domain = domain.lower().strip()

    # =========================
    # DIRECT DOMAIN ACCESS (NEW STRUCTURE)
    # =========================
    if domain in data:
        domain_data = data[domain]

        beg = domain_data.get("beginner", [])
        inter = domain_data.get("intermediate", [])
        adv = domain_data.get("experienced", [])

        selected = weighted_selection(beg, inter, adv, exp, past)

        return add_ids(selected)

    # =========================
    # OPTIONAL: WEB DEV SUBDOMAIN SUPPORT
    # =========================
    if domain == "web-development" and backend:
        backend = backend.lower()

        web_data = data.get("web-development", {})

        if backend in web_data:
            sub = web_data[backend]

            selected = weighted_selection(
                sub.get("beginner", []),
                sub.get("intermediate", []),
                sub.get("experienced", []),
                exp,
                past
            )

            return add_ids(selected)

    return []