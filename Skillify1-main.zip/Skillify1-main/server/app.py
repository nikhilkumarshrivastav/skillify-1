from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, conlist
from typing import Optional, List
import numpy as np
import requests
import os

# import routes
from auth_routes import router as auth_router
from generate_questions import get_questions

app = FastAPI()

# ---------------- CORS ----------------
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# include auth routes
app.include_router(auth_router)

# =========================================================
# 📦 REQUEST MODELS
# =========================================================

class QuizRequest(BaseModel):
    domain: str
    programming_exp: str
    past_experience: str
    backend_tech: Optional[str] = None


class AnalyzeRequest(BaseModel):
    answers: conlist(int, min_length=1)


# =========================================================
# 🎯 GET QUIZ
# =========================================================

@app.post("/get-quiz")
def get_quiz(data: QuizRequest):
    try:
        questions = get_questions(
            data.domain,
            data.programming_exp,
            data.past_experience,
            data.backend_tech,
        )

        return {
            "domain": data.domain,
            "total_questions": len(questions),
            "questions": questions
        }

    except Exception as e:
        return {"error": str(e)}


# =========================================================
# 🧠 ANALYZE QUIZ
# =========================================================

@app.post("/analyze-quiz")
def analyze_quiz(data: AnalyzeRequest):
    try:
        answers = data.answers

        arr = np.array(answers)
        arr = np.clip(arr, 0, 1)  # safety

        score = int((np.sum(arr) / len(arr)) * 100)

        if score >= 80:
            level = "Advanced"
        elif score >= 55:
            level = "Intermediate"
        else:
            level = "Beginner"

        if level == "Beginner":
            strengths = ["Basic Awareness"]
            weaknesses = ["Core Fundamentals"]
        elif level == "Intermediate":
            strengths = ["Core Fundamentals", "Problem Solving"]
            weaknesses = ["Advanced Concepts"]
        else:
            strengths = ["Strong Fundamentals", "Advanced Concepts"]
            weaknesses = ["Minor Gaps"]

        return {
            "score": score,
            "level": level,
            "strengths": strengths,
            "weaknesses": weaknesses
        }

    except Exception as e:
        return {"error": str(e)}


# =========================================================
# 🎥 YOUTUBE RECOMMENDER
# =========================================================

API_KEY = os.getenv("YOUTUBE_API_KEY")


def fetch_videos(query):
    url = "https://www.googleapis.com/youtube/v3/search"

    if not API_KEY:
        return []

    try:
        response = requests.get(
            url,
            params={
                "part": "snippet",
                "q": query,
                "key": API_KEY,
                "maxResults": 5,
                "type": "video"
            },
            timeout=5
        )

        if response.status_code != 200:
            return []

        data = response.json()

        videos = []
        for item in data.get("items", []):
            if "videoId" not in item.get("id", {}):
                continue

            videos.append({
                "title": item["snippet"]["title"],
                "video_id": item["id"]["videoId"]
            })

        return videos

    except Exception:
        return []


def get_video_stats(video_ids):
    if not video_ids or not API_KEY:
        return {}

    url = "https://www.googleapis.com/youtube/v3/videos"

    try:
        response = requests.get(
            url,
            params={
                "part": "statistics",
                "id": ",".join(video_ids),
                "key": API_KEY
            },
            timeout=5
        )

        if response.status_code != 200:
            return {}

        data = response.json()

        stats = {}
        for item in data.get("items", []):
            stats[item["id"]] = {
                "views": int(item["statistics"].get("viewCount", 0)),
                "likes": int(item["statistics"].get("likeCount", 0)),
                "comments": int(item["statistics"].get("commentCount", 0)),
            }

        return stats

    except Exception:
        return {}

def rank_videos(videos, stats):
    ranked = []

    for v in videos:
        vid = v["video_id"]
        s = stats.get(vid, {"views": 1, "likes": 0, "comments": 0})

        views = max(s["views"], 1)
        likes = s["likes"]
        comments = s["comments"]

        like_ratio = likes / views

        score = (
            views * 0.5 +
            likes * 0.3 +
            comments * 0.2 +
            like_ratio * 100000
        )

        ranked.append({
            "title": v["title"],
            "link": f"https://www.youtube.com/watch?v={vid}",
            "score": score
        })

    ranked.sort(key=lambda x: x["score"], reverse=True)

    return [{"title": v["title"], "link": v["link"]} for v in ranked]

@app.get("/recommend")
def recommend(topic: str):
    if not topic.strip():
        return {"error": "Topic is required"}

    if not API_KEY:
        return {"error": "YouTube API key not configured"}

    query = f"{topic} full course tutorial"

    videos = fetch_videos(query)
    video_ids = [v["video_id"] for v in videos]

    stats = get_video_stats(video_ids)
    ranked = rank_videos(videos, stats)

    return {
        "topic": topic,
        "results": ranked[:5]
    }


# =========================================================
# ROOT
# =========================================================

@app.get("/")
def root():
    return {"message": "Skillify API running 🚀"}